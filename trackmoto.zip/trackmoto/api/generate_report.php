<?php
require_once __DIR__ . '/../vendor/autoload.php';

$pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('SMDI');
$pdf->SetTitle('Document Report');
$pdf->SetSubject('Document Report');
$pdf->SetKeywords('TCPDF, PDF, report, document');

$pdf->SetHeaderData('', 0, 'Document Report', 'Generated on ' . date('Y-m-d H:i:s'));

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->SetFont('helvetica', '', 12);

$pdf->AddPage();

$reportType = isset($_POST['reportType']) ? $_POST['reportType'] : 'both';
$documentType = isset($_POST['reportDocumentType']) ? $_POST['reportDocumentType'] : 'both';
$startDate = isset($_POST['startDate']) ? $_POST['startDate'] : '0000-00-00';
$endDate = isset($_POST['endDate']) ? $_POST['endDate'] : '9999-99-99';
$status = isset($_POST['reportStatus']) ? $_POST['reportStatus'] : '';

$startDate = date('Y-m-d', strtotime(str_replace('/', '-', $startDate)));
$endDate = date('Y-m-d', strtotime(str_replace('/', '-', $endDate)));

include 'db_config.php';

$sql = "SELECT dr.*, c.family_name, c.first_name, c.middle_initial, c.branch, d.document_type, d.status
        FROM document_records dr
        LEFT JOIN customers c ON dr.customer_id = c.customer_id
        LEFT JOIN documents d ON c.customer_id = d.customer_id
        WHERE dr.date_reg BETWEEN ? AND ?";

$params = [$startDate, $endDate];
$types = 'ss';

if ($documentType !== 'both') {
    $sql .= " AND d.document_type = ?";
    $params[] = ($documentType === 'orcr') ? 'OR/CR' : 'LTO Plate Number';
    $types .= 's';
}

if ($status !== '' && $status !== 'all') {
    $sql .= " AND d.status = ?";
    $params[] = ($status === 'on_processing') ? 'On Processing' :
                (($status === 'ready_for_pick_up') ? 'Ready for Pick Up' : 'Released');
    $types .= 's';
}

$stmt = $conn->prepare($sql);

$stmt->bind_param($types, ...$params);
$stmt->execute();

$result = $stmt->get_result();

$html = '<h1>Document Report</h1>';
$html .= '<table border="1" cellpadding="5">';
$html .= '<thead><tr><th>ID</th><th>Customer Name</th><th>Document Type</th><th>Document Number</th><th>Status</th><th>Date Registered</th></tr></thead>';
$html .= '<tbody>';

while ($row = $result->fetch_assoc()) {
    $html .= '<tr>';
    $html .= '<td>' . htmlspecialchars($row['record_id']) . '</td>';
    $html .= '<td>' . htmlspecialchars($row['family_name'] . ', ' . $row['first_name'] . ' ' . $row['middle_initial']) . '</td>';
    $html .= '<td>' . htmlspecialchars($row['document_type']) . '</td>';
    $html .= '<td>' . htmlspecialchars($row['document_number']) . '</td>';
    $html .= '<td>' . htmlspecialchars($row['status']) . '</td>';
    $html .= '<td>' . htmlspecialchars($row['date_reg']) . '</td>';
    $html .= '</tr>';
}

$html .= '</tbody>';
$html .= '</table>';

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output('document_report.pdf', 'I');
?>
