<?php
include 'db_config.php';


// Initialize response array
$response = [
    'status' => 'error',
    'message' => 'An error occurred while fetching the notification details.',
    'data' => []
];

// Retrieve input parameter
$notificationId = $_POST['id'] ?? '';

// Validate input
if (empty($notificationId)) {
    $response['message'] = 'Notification ID is required.';
    echo json_encode($response);
    exit;
}

// Prepare and execute the query
$sql = "SELECT contact_number, message FROM follow_ups WHERE id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    $response['message'] = 'Failed to prepare the SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param('i', $notificationId);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $notification = $result->fetch_assoc();

    if ($notification) {
        $response['status'] = 'success';
        $response['message'] = 'Notification details retrieved successfully.';
        $response['data'] = $notification;
    } else {
        $response['message'] = 'Notification not found.';
    }
} else {
    $response['message'] = 'An error occurred while executing the query.';
}

$stmt->close();
$conn->close();

// Return the response
echo json_encode($response);
?>
