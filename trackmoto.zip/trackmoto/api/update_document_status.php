<?php
include 'db_config.php';

if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User  not logged in.']);
    exit();
}

$loggedInUser  = $_SESSION['username']; // Adjust based on how you store user info

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $documentId = filter_input(INPUT_POST, 'documentId', FILTER_SANITIZE_NUMBER_INT);
    $status = htmlspecialchars(trim(filter_input(INPUT_POST, 'status', FILTER_DEFAULT)), ENT_QUOTES);
    
    $conn->begin_transaction();

    try {
        // Prepare the action log message
        $actionLog = "Updated document status to '$status' by " . $loggedInUser ;

        // Update the document status, last_updated, updated_by, and action
        $stmt = $conn->prepare("UPDATE documents SET status = ?, last_updated = CURRENT_TIMESTAMP, updated_by = ?, action = ? WHERE document_id = ?");
        $stmt->bind_param("sssi", $status, $loggedInUser , $actionLog, $documentId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to execute statement: ' . $stmt->error);
        }

        $stmt->close();
        $conn->commit();
        echo json_encode(['status' => 'success', 'message' => 'Status updated successfully.']);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Failed to update status. Error: ' . $e->getMessage()]);
    }

    $conn->close();
}
?>