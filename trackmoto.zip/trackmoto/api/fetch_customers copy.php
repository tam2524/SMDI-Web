<?php
include 'db_config.php';

// Sanitize the query parameter
$query = isset($_GET['query']) ? htmlspecialchars($_GET['query']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$recordsPerPage = 15;
$offset = ($page - 1) * $recordsPerPage;

// Prepare SQL query with placeholders for pagination
$sql = "SELECT * FROM customers 
        WHERE family_name LIKE ? 
        OR first_name LIKE ? 
        OR middle_initial LIKE ? 
        LIMIT ?, ?";

// Prepare the SQL statement
$stmt = mysqli_prepare($conn, $sql);
if ($stmt === false) {
    echo "<tr><td colspan='6'>Failed to prepare SQL statement.</td></tr>";
    exit;
}

// Sanitize and bind parameters
$searchTerm = "%$query%";
mysqli_stmt_bind_param($stmt, "ssii", $searchTerm, $searchTerm, $offset, $recordsPerPage);

// Execute the statement
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
    while ($customer = mysqli_fetch_assoc($result)) {
        // Sanitize the output data
        $customerId = htmlspecialchars($customer['customer_id']);
        $familyName = htmlspecialchars($customer['family_name']);
        $firstName = htmlspecialchars($customer['first_name']);
        $middleInitial = htmlspecialchars($customer['middle_initial']);
        $branch = htmlspecialchars($customer['branch']);
        
        // Output HTML table row
        echo "<tr data-id='{$customerId}'>
                <td class='no-print'><input type='checkbox' name='customerCheckbox'></td>
                <td>{$familyName}</td>
                <td>{$firstName}</td>
                <td>{$middleInitial}</td>
                <td>{$branch}</td>
                <td class='no-print'>
                    <button class='btn btn-sm text-white btn-primary edit-button'>View Motorcycle</button>
                </td>
              </tr>";
    }
} else {
    // No records found
    echo "<tr><td colspan='6'>No records found</td></tr>";
}

// Get total records for pagination
$totalQuery = "SELECT COUNT(*) FROM customers 
               WHERE family_name LIKE ? 
               OR first_name LIKE ? 
               OR middle_initial LIKE ?";
$totalStmt = mysqli_prepare($conn, $totalQuery);
mysqli_stmt_bind_param($totalStmt, "ss", $searchTerm, $searchTerm);
mysqli_stmt_execute($totalStmt);
mysqli_stmt_bind_result($totalStmt, $totalRecords);
mysqli_stmt_fetch($totalStmt);
mysqli_stmt_close($totalStmt);

// Calculate total pages
$totalPages = ceil($totalRecords / $recordsPerPage);

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);

// Output pagination links
for ($i = 1; $i <= $totalPages; $i++) {
    echo "<a href='?query={$query}&page={$i}'>{$i}</a> ";
}
?>
