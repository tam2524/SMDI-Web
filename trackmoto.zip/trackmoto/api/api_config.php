<?php
return [
    'apiKey' => 'b51e074a6aea5e1c028ff91d30eff9f5',
    'senderName' => 'SMDI', 
];
