<?php
include 'db_config.php';


$user_id = $_POST['user_id'];
$new_password = $_POST['new_password'];

// Hash the new password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

// Prepare the SQL statement with placeholders for parameters
$sql = "UPDATE users 
        SET password = ?
        WHERE id = ?";

// Prepare the statement
$stmt = mysqli_prepare($conn, $sql);

// Bind the parameters to the statement
// 'si' means string, integer
mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);

// Execute the statement
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(['status' => 'success', 'message' => 'Password reset successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to reset password.']);
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
