<?php
include 'db_config.php';


header('Content-Type: application/json');

// SQL query to fetch notifications and join with documents table
$sql = "
    SELECT f.id, f.document_id, f.customer_name, f.contact_number, f.message, f.response_message, f.created_at, f.status, 
           d.status AS document_status, d.document_type AS document_name
    FROM follow_ups f
    LEFT JOIN documents d ON f.document_id = d.document_id
    ORDER BY f.created_at DESC
";

if ($result = $conn->query($sql)) {
    $notifications = array();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $result->free();
    echo json_encode(array('status' => 'success', 'data' => $notifications));
} else {
    echo json_encode(array('status' => 'error', 'message' => $conn->error));
}

// Close the connection
$conn->close();
?>
