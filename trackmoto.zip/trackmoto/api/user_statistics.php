<?php
include 'db_config.php';


$response = array();

$query = "SELECT MONTH(created_at) AS month, COUNT(*) AS userCount FROM users GROUP BY MONTH(created_at)";
$result = mysqli_query($conn, $query);

$months = [];
$counts = [];

while ($row = mysqli_fetch_assoc($result)) {
    $months[] = $row['month'];
    $counts[] = $row['userCount'];
}

$response['months'] = $months;
$response['counts'] = $counts;

echo json_encode($response);

mysqli_close($conn);
?>
