<?php
include 'db_config.php';

if (!isset($_SESSION['username'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

$searchQuery = isset($_GET['query']) ? $conn->real_escape_string($_GET['query']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$recordsPerPage = 15; 
$offset = ($page - 1) * $recordsPerPage;

// Get sorting parameters
$sortColumn = isset($_GET['sort']) ? $conn->real_escape_string($_GET['sort']) : 'family_name';
$sortOrder = isset($_GET['order']) && strtoupper($_GET['order']) === 'DESC' ? 'DESC' : 'ASC';

// SQL query for fetching customers
$query = "SELECT * FROM customers WHERE 1=1";

if ($searchQuery) {
    $query .= " AND (family_name LIKE '%$searchQuery%' OR first_name LIKE '%$searchQuery%' OR middle_initial LIKE '%$searchQuery%')";
}

$query .= " ORDER BY $sortColumn $sortOrder LIMIT $offset, $recordsPerPage";

// Get total records for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM customers WHERE 1=1";
if ($searchQuery) {
    $totalQuery .= " AND (family_name LIKE '%$searchQuery%' OR first_name LIKE '%$searchQuery%' OR middle_initial LIKE '%$searchQuery%')";
}

$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $recordsPerPage);

// Fetch records
$result = $conn->query($query);
$response = [];
$response['totalPages'] = $totalPages;
$response['customers'] = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response['customers'][] = $row;
    }
} 

echo json_encode($response);
$conn->close();
?>
