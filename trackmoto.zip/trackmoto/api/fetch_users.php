<?php
include 'db_config.php';



$query = $_GET['query'] ?? '';

$sql = "SELECT * FROM users WHERE username LIKE ?";

$stmt = mysqli_prepare($conn, $sql);
$searchTerm = "%$query%";
mysqli_stmt_bind_param($stmt, "s", $searchTerm);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) > 0) {
    while ($user = mysqli_fetch_assoc($result)) {
        echo "<tr data-id='{$user['id']}'>
                <td class='no-print'><input type='checkbox' name='UserCheckbox'></td>
                <td>{$user['username']}</td>
                <td>{$user['position']}</td>
                <td>{$user['created_at']}</td>
                <td class='no-print'>
                    <button class='btn btn-sm text-white btn-primary edit-button'>Edit</button>
         
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='10'>No users found</td></tr>";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
