<?php
include 'db_config.php';

header('Content-Type: application/json');

// Initialize an array to hold all action logs
$actionLogs = [];

// Fetch logs from the documents table
$documentsQuery = "SELECT document_id AS id, status, encoded_by, last_updated FROM documents ORDER BY last_updated DESC";
$documentsResult = $conn->query($documentsQuery);
while ($row = $documentsResult->fetch_assoc()) {
    $row['table'] = 'documents'; // Add source table info
    $actionLogs[] = $row;
}

// Fetch logs from the document_records table
$documentRecordsQuery = "SELECT record_id AS id, action AS status, encoded_by, last_updated FROM document_records ORDER BY last_updated DESC";
$documentRecordsResult = $conn->query($documentRecordsQuery);
while ($row = $documentRecordsResult->fetch_assoc()) {
    $row['table'] = 'document_records'; // Add source table info
    $actionLogs[] = $row;
}

// Fetch logs from the customers table
$customersQuery = "SELECT customer_id AS id, action AS status, encoded_by, last_updated FROM customers ORDER BY last_updated DESC";
$customersResult = $conn->query($customersQuery);
while ($row = $customersResult->fetch_assoc()) {
    $row['table'] = 'customers'; // Add source table info
    $actionLogs[] = $row;
}

// Fetch logs from the motorcycles table
$motorcyclesQuery = "SELECT id AS id, action AS status, encoded_by, last_updated FROM motorcycles ORDER BY last_updated DESC";
$motorcyclesResult = $conn->query($motorcyclesQuery);
while ($row = $motorcyclesResult->fetch_assoc()) {
    $row['table'] = 'motorcycles'; // Add source table info
    $actionLogs[] = $row;
}

// Sort the combined logs by last_updated in descending order
usort($actionLogs, function ($a, $b) {
    return strtotime($b['last_updated']) - strtotime($a['last_updated']);
});

// Return the combined action logs as JSON
echo json_encode($actionLogs);
$conn->close();
?>