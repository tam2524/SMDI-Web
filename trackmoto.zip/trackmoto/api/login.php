<?php
include 'db_config.php';

header('Content-Type: application/json'); 

$username = $_POST['username'];
$password = $_POST['password'];

// Check for existing login attempts
$attemptStmt = $conn->prepare("SELECT attempts, last_attempt FROM login_attempts WHERE username = ?");
$attemptStmt->bind_param("s", $username);
$attemptStmt->execute();
$attemptResult = $attemptStmt->get_result();

if ($attemptResult->num_rows > 0) {
    $attemptData = $attemptResult->fetch_assoc();
    $attempts = $attemptData['attempts'];
    $lastAttempt = $attemptData['last_attempt'];
} else {
    // If no entry exists, initialize attempts
    $attempts = 0;
    $lastAttempt = null;
}

// Check if the user is locked out
if ($attempts >= 3 && (strtotime($lastAttempt) + 300) > time()) { // 5 minutes lockout
    echo json_encode(['error' => 'Account locked. Please try again later.']);
    exit();
}

// Proceed with login
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['position'] = $user['position'];

        // Reset login attempts on successful login
        if ($attemptResult->num_rows > 0) {
            $resetStmt = $conn->prepare("UPDATE login_attempts SET attempts = 0 WHERE username = ?");
            $resetStmt->bind_param("s", $username);
            $resetStmt->execute();
            $resetStmt->close();
        }

        switch (trim($user['position'])) {
            case 'Staff':
                echo json_encode(['success' => true, 'redirect' => '../trackmoto/staff_dashboard.php']);
                break;
            case 'Admin':
                echo json_encode(['success' => true, 'redirect' => '../trackmoto/admin_dashboard.php']);
                break;
            default:
                echo json_encode(['success' => true, 'redirect' => '../login.html']);
                break;
        }
    } else {
        // Increment login attempts
        if ($attemptResult->num_rows > 0) {
            $attempts++;
            $updateStmt = $conn->prepare("UPDATE login_attempts SET attempts = ?, last_attempt = CURRENT_TIMESTAMP WHERE username = ?");
            $updateStmt->bind_param("is", $attempts, $username);
            $updateStmt->execute();
            $updateStmt->close();
        } else {
            // Insert new entry for login attempts
            $insertStmt = $conn->prepare("INSERT INTO login_attempts (username, attempts, last_attempt) VALUES (?, 1, CURRENT_TIMESTAMP)");
            $insertStmt->bind_param("s", $username);
            $insertStmt->execute();
            $insertStmt->close();
        }
        
        echo json_encode(['error' => 'Invalid username or password']);
    }
} else {
    // Increment login attempts
    if ($attemptResult->num_rows > 0) {
        $attempts++;
        $updateStmt = $conn->prepare("UPDATE login_attempts SET attempts = ?, last_attempt = CURRENT_TIMESTAMP WHERE username = ?");
        $updateStmt->bind_param("is", $attempts, $username);
        $updateStmt->execute();
        $updateStmt->close();
    } else {
        // Insert new entry for login attempts
        $insertStmt = $conn->prepare("INSERT INTO login_attempts (username, attempts, last_attempt) VALUES (?, 1, CURRENT_TIMESTAMP)");
        $insertStmt->bind_param("s", $username);
        $insertStmt->execute();
        $insertStmt->close();
    }
    
    echo json_encode(['error' => 'Invalid username or password']);
}

$stmt->close();
$conn->close();
?>