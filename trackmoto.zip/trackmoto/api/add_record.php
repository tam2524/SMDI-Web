<?php
session_start();
include 'db_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User  not logged in.']);
    exit();
}

// Gather data from POST request
$encodedBy = $_SESSION['username'];
$dateReg = $_POST['date_reg'];
$familyName = $_POST['family_name'];
$firstName = $_POST['first_name'];
$middleInitial = $_POST['middle_initial'];
$plateNumber = $_POST['plate_number'];
$mvFile = $_POST['mv_file'];
$branch = $_POST['branch'];
$batch = $_POST['batch'];
$remarks = $_POST['remarks'];

// Motorcycle details
$engineNo = $_POST['engineNo'];
$chassisNo = $_POST['chassisNo'];
$make = $_POST['make'];
$yearModel = $_POST['yearModel'];
$series = $_POST['series'];
$bodyType = $_POST['bodyType'];
$denomination = $_POST['denomination'];
$datePurchase = $_POST['datePurchase'];

mysqli_begin_transaction($conn);

try {
    // Check for duplicates only if mv_file and plate_number are not "ND"
    if ($mvFile !== "ND" || $plateNumber !== "ND") {
        $checkDuplicateQuery = "SELECT * FROM document_records WHERE (mv_file = ? AND mv_file <> 'ND') OR (plate_number = ? AND plate_number <> 'ND')";
        $checkStmt = mysqli_prepare($conn, $checkDuplicateQuery);
        mysqli_stmt_bind_param($checkStmt, "ss", $mvFile, $plateNumber);
        mysqli_stmt_execute($checkStmt);
        mysqli_stmt_store_result($checkStmt);

        if (mysqli_stmt_num_rows($checkStmt) > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Duplicate MV number or plate number found.']);
            mysqli_stmt_close($checkStmt);
            exit();
        }
        mysqli_stmt_close($checkStmt);
    }

    // Insert record into `document_records`
    $sql1 = "INSERT INTO document_records (date_reg, family_name, first_name, middle_initial, plate_number, mv_file, branch, batch, remarks, encoded_by, action) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $actionLog = "Inserted document record by " . $encodedBy;
    $stmt1 = mysqli_prepare($conn, $sql1);
    mysqli_stmt_bind_param($stmt1, "sssssssssss", $dateReg, $familyName, $firstName, $middleInitial, $plateNumber, $mvFile, $branch, $batch, $remarks, $encodedBy, $actionLog);

    if (!mysqli_stmt_execute($stmt1)) {
        throw new Exception('Failed to add document record.');
    }
    
    $recordId = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt1);

    // Check if customer already exists
    $customerCheckQuery = "SELECT customer_id FROM customers WHERE family_name = ? AND first_name = ? AND middle_initial = ? AND branch = ?";
    $customerCheckStmt = mysqli_prepare($conn, $customerCheckQuery);
    mysqli_stmt_bind_param($customerCheckStmt, "ssss", $familyName, $firstName, $middleInitial, $branch);
    mysqli_stmt_execute($customerCheckStmt);
    mysqli_stmt_bind_result($customerCheckStmt, $customerId);
    mysqli_stmt_fetch($customerCheckStmt);
    mysqli_stmt_close($customerCheckStmt);

    // Insert or update customer record
    if ($customerId) {
        // Update existing customer
        $stmt2 = mysqli_prepare($conn, "UPDATE customers SET record_id = ?, action = ? WHERE customer_id = ?");
        $actionLog = "Updated customer record by " . $encodedBy;
        mysqli_stmt_bind_param($stmt2, "isi", $recordId, $actionLog, $customerId);
    } else {
        // Insert new customer
        $stmt2 = mysqli_prepare($conn, "INSERT INTO customers (family_name, first_name, middle_initial, branch, record_id, action) VALUES (?, ?, ?, ?, ?, ?)");
        $actionLog = "Inserted new customer record by " . $encodedBy;
        mysqli_stmt_bind_param($stmt2, "ssssis", $familyName, $firstName, $middleInitial, $branch, $recordId, $actionLog);
    }

    if (!mysqli_stmt_execute($stmt2)) {
        throw new Exception('Failed to add or update customer.');
    }
    
    if (!$customerId) {
        $customerId = mysqli_insert_id($conn);
    }
    mysqli_stmt_close($stmt2);

    // Update record with customer_id
    $stmt3 = mysqli_prepare($conn, "UPDATE document_records SET customer_id = ? WHERE record_id = ?");
    mysqli_stmt_bind_param($stmt3, "ii", $customerId, $recordId);
    if (!mysqli_stmt_execute($stmt3)) {
        throw new Exception('Failed to update record with customer ID.');
    }
    mysqli_stmt_close($stmt3);

    // Insert OR/CR document
    $stmt4 = mysqli_prepare($conn, "INSERT INTO documents (customer_id, document_type, document_number, status, action) VALUES (?, 'OR/CR', ?, 'On Processing', ?)");
    $actionLog = "Inserted OR/CR document for customer ID " . $customerId . " by " . $encodedBy;
    mysqli_stmt_bind_param($stmt4, "iss", $customerId, $mvFile, $actionLog);
    if (!mysqli_stmt_execute($stmt4)) {
        throw new Exception('Failed to add OR/CR document.');
    }
    mysqli_stmt_close($stmt4);

    // Insert LTO Plate Number document
    $stmt5 = mysqli_prepare($conn, "INSERT INTO documents (customer_id, document_type, document_number, status, action) VALUES (?, 'LTO Plate Number', ?, 'On Processing', ?)");
    $actionLog = "Inserted LTO Plate Number document for customer ID " . $customerId . " by " . $encodedBy;
    mysqli_stmt_bind_param($stmt5, "iss", $customerId, $plateNumber, $actionLog);
    if (!mysqli_stmt_execute($stmt5)) {
        throw new Exception('Failed to add LTO Plate Number document.');
    }
    mysqli_stmt_close($stmt5);

    // Insert motorcycle details
    $stmt6 = mysqli_prepare($conn, "INSERT INTO motorcycles (engine_no, chassis_no, denomination, make, series, body_type, year_model, date_purchase, customer_id, action) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $actionLog = "Inserted motorcycle details for customer ID " . $customerId . " by " . $encodedBy;
    mysqli_stmt_bind_param($stmt6, "ssssssssis", $engineNo, $chassisNo, $denomination, $make, $series, $bodyType, $yearModel, $datePurchase, $customerId, $actionLog);
    if (!mysqli_stmt_execute($stmt6)) {
        throw new Exception('Failed to add motorcycle details.');
    }
    mysqli_stmt_close($stmt6);

    // Commit transaction
    mysqli_commit($conn);
    echo json_encode(['status' => 'success', 'message' => 'Record and documents added successfully.']);
} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(['status' => 'error', 'message' => 'Failed to add record. Error: ' . $e->getMessage()]);
}

mysqli_close($conn);
?>
