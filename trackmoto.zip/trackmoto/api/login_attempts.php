<?php
header('Content-Type: application/json');
include 'db_config.php'; // Include your database connection

$query = "SELECT username, attempts, last_attempt FROM login_attempts"; // Adjust the query as needed
$result = $conn->query($query);

$loginAttempts = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $loginAttempts[] = $row;
    }
}

echo json_encode($loginAttempts);
$conn->close();
?>