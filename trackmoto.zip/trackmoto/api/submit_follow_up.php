<?php
include 'db_config.php';



$documentId = $_POST['documentId'];
$customerName = $_POST['customerName'];
$contactNumber = $_POST['contactNumber'];
$followUpMessage = $_POST['followUpMessage'];

$sql = "INSERT INTO follow_ups (document_id, customer_name, contact_number, message) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ssss', $documentId, $customerName, $contactNumber, $followUpMessage);

if ($stmt->execute()) {
    echo json_encode(['success' => 'Follow-up saved successfully.']);
} else {
    echo json_encode(['error' => 'Error: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>