<?php
require_once '../vendor/autoload.php'; // Adjust the path as needed

use Twilio\Rest\Client;

// Twilio credentials
$sid = 'AC0646fa5ef55f361a592880001e6d27ee'; // Replace with your Twilio SID
$token = '4fc780eae6c59919f7d45873740eeece'; // Replace with your Twilio Auth Token
$twilio_number = '+12073869358'; // Replace with your Twilio phone number
// Create a new Twilio client
$client = new Client($sid, $token);

// Get POST data
$notificationId = $_POST['notificationId'] ?? '';
$contactNumber = $_POST['contactNumber'] ?? '';
$responseMessage = $_POST['responseMessage'] ?? '';

// Function to format Philippine phone numbers
function formatPhilippineNumber($number) {
    // Remove all non-digit characters
    $number = preg_replace('/\D/', '', $number);

    // Check if the number starts with '0' and remove it
    if (strpos($number, '0') === 0) {
        $number = substr($number, 1);
    }

    // Add the Philippine country code
    return '+63' . $number;
}

$response = [
    'status' => 'error',
    'message' => 'An unexpected error occurred.'
];

try {
    if (empty($notificationId) || empty($contactNumber) || empty($responseMessage)) {
        throw new Exception('Required data missing.');
    }

    // Format the phone number
    $contactNumber = formatPhilippineNumber($contactNumber);

    // Send SMS using Twilio
    $message = $client->messages->create(
        $contactNumber, 
        [
            'from' => $twilio_number,
            'body' => $responseMessage
        ]
    );

    // Check if the message was successfully sent
    if ($message->sid) {
        $response = [
            'status' => 'success',
            'message' => 'Response sent successfully.'
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Failed to send response.'
        ];
    }
} catch (Exception $e) {
    $response = [
        'status' => 'error',
        'message' => $e->getMessage()
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
?>