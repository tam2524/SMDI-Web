<?php
require_once __DIR__ . '/../vendor/autoload.php'; // Adjust the path if needed
include 'db_config.php'; // Your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the selected report parameters from the form
    $reportType = $_POST['report_type'] ?? null;
    $timeFrame = $_POST['time_frame'] ?? null;
    $startDate = $_POST['start_date'] ?? null;
    $endDate = $_POST['end_date'] ?? null;
    $documentStatus = $_POST['document_status'] ?? 'all'; // Default to 'all'
    $fileType = $_POST['file_type'] ?? 'pdf'; // Default to PDF

    // Validate date inputs if custom time frame is selected
    if ($timeFrame === 'custom' && (!validateDate($startDate) || !validateDate($endDate))) {
        die("Invalid date format. Please use 'YYYY-MM-DD'.");
    }

    // Prepare the query based on the selected filters
    $stmt = getQuery($conn, $reportType, $timeFrame, $startDate, $endDate, $documentStatus);

    // Execute the query
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the result set is not empty
        if ($result->num_rows > 0) {
            // Generate report based on file type
            switch ($fileType) {
                case 'pdf':
                    generatePDFReport($result, $reportType, $timeFrame, $startDate, $endDate);
                    break;
                case 'excel':
                    generateExcelReport($result);
                    break;
                default:
                    echo "Invalid file type selected.";
                    exit;
            }
        } else {
            echo "<div style='text-align: center; padding: 20px;'>
                    <h2>No Records Found</h2>
                    <p>Unfortunately, we couldn't find any records that match your search criteria.</p>
                    <p>Please check your filters or try a different search.</p>
                  </div>";
        }
    } else {
        echo "Error preparing the query. Please check your inputs.";
    }

    $stmt->close();
    exit; // Ensure no further output is sent
}

// Function to prepare the query based on report type, timeframe, and document status
function getQuery($conn, $reportType, $timeFrame, $startDate, $endDate, $documentStatus) {
    $sql = "SELECT d.document_type, d.document_number, d.status, c.family_name, c.first_name 
            FROM documents d
            LEFT JOIN customers c ON d.customer_id = c.customer_id 
            WHERE 1=1"; // "1=1" for easy appending of conditions

    $params = [];

    // Append conditions for report type
    if ($reportType !== 'all') {
        $sql .= " AND d.document_type = ?";
        $params[] = $reportType;
    }

    // Append conditions for date filtering
   // Append conditions for date filtering
if ($timeFrame === 'custom') {
    $sql .= " AND d.created_at BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
} elseif ($timeFrame === 'weekly') {
    $sql .= " AND d.created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)";
} elseif ($timeFrame === 'monthly') {
    $sql .= " AND d.created_at >= DATE_FORMAT(CURDATE() ,'%Y-%m-01')";
} elseif ($timeFrame === 'yearly') {
    $sql .= " AND d.created_at >= DATE_FORMAT(CURDATE() ,'%Y-01-01')";
}

    // Append conditions for document status
    if ($documentStatus !== 'all') {
        $sql .= " AND d.status = ?";
        $params[] = $documentStatus;
    }

    // Prepare the statement with dynamic binding
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        // Bind parameters dynamically
        if (!empty($params)) {
            $stmt->bind_param(str_repeat('s', count($params)), ...$params);
        }
        return $stmt; // Return the prepared statement
    }

    return null; // Invalid query
}

// Function to validate date format
function validateDate($date) {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

// Generate PDF report
function generatePDFReport($result, $reportType, $timeFrame, $startDate, $endDate) {
    // Create a new PDF document in portrait format
    $pdf = new \TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Solid Motorcycle Distributors, Inc.');
    $pdf->SetTitle('Document Report');
    $pdf->SetSubject('Generated Report');
    $pdf->SetKeywords('TCPDF, PDF, report');

    // Set margins to 1 inch (25.4 mm)
    $pdf->SetMargins(25.4, 25.4, 25.4);
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    $pdf->AddPage();

    // Generate the header
    generatePDFHeader($pdf, $reportType, $timeFrame, $startDate, $endDate);

    // Set table header
    $pdf->SetFont('helvetica', 'B', 10);
    $headerTitles = ['Type', 'Document Number', 'Status', 'Customer'];
    $headerWidths = [50, 50, 30, 50]; // Adjust widths accordingly
    $totalWidth = array_sum($headerWidths); // Calculate total width of the table

    // Center the table by calculating the X position
    $xPosition = ($pdf->getPageWidth() - $totalWidth) / 2;

    // Set position for header
    $pdf->SetX($xPosition);
    foreach ($headerTitles as $index => $title) {
        $pdf->Cell($headerWidths[$index], 10, $title, 1, 0, 'C');
    }
    $pdf->Ln();

    // Set table data
    $pdf->SetFont('helvetica', '', 10);
    while ($row = $result->fetch_assoc()) {
        $pdf->SetX($xPosition); // Reset X position for each row
        $pdf->Cell($headerWidths[0], 10, htmlspecialchars($row['document_type']), 1);
        $pdf->Cell($headerWidths[1], 10, htmlspecialchars($row['document_number']), 1);
        $pdf->Cell($headerWidths[2], 10, htmlspecialchars($row['status']), 1);
        
        // Combine first and last name with word wrap
        $customerName = htmlspecialchars($row['family_name'] . ', ' . $row['first_name']);
        $pdf->MultiCell($headerWidths[3], 10, $customerName, 1, 'C', 0); // Word wrap the customer name
        $pdf->Ln(0); // Move to the next row
    }

    // Output the PDF
    $pdf->Output('document_report.pdf', 'I');
}

// Function to generate the header for the PDF
function generatePDFHeader($pdf, $reportType, $timeFrame, $startDate, $endDate) {
    // Disable the default header and footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Add company logo
    $logoFilePath = __DIR__ . '/../img/smdi_logo.png'; // Relative path
    if (file_exists($logoFilePath)) {
        $pdf->Image($logoFilePath, ($pdf->getPageWidth() - 40) / 2, 15, 30, '', 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
    } else {
        error_log("Logo file not found: " . $logoFilePath);
    }

    // Set company name
    $pdf->SetFont('helvetica', 'B', 20);
    $pdf->Cell(0, 5, 'Solid Motorcycle Distributors, Inc.', 0, 1, 'C');

    // Set report title
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Document Report', 0, 1, 'C');

    // Set report details
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'Report Type: ' . htmlspecialchars($reportType), 0, 1, 'C');
    if ($timeFrame === 'custom') {
        $pdf->Cell(0, 10, 'From: ' . htmlspecialchars($startDate) . ' To: ' . htmlspecialchars($endDate), 0, 1, 'C');
    }
    $pdf->Ln(5);
}

// Generate Excel report
function generateExcelReport($result) {
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header
    $headers = ['Type', 'Document Number', 'Status', 'Customer'];
    $sheet->fromArray($headers, NULL, 'A1');

    // Fill data
    $rowNumber = 2; // Start from the second row
    while ($row = $result->fetch_assoc()) {
        $sheet->setCellValue
        ('A' . $rowNumber, htmlspecialchars($row['document_type']));
        $sheet->setCellValue('B' . $rowNumber, htmlspecialchars($row['document_number']));
        $sheet->setCellValue('C' . $rowNumber, htmlspecialchars($row['status']));
        $sheet->setCellValue('D' . $rowNumber, htmlspecialchars($row['family_name'] . ', ' . $row['first_name']));
        $rowNumber++;
    }

    // Auto-adjust column widths
    foreach (range('A', 'D') as $columnID) {
        $sheet->getColumnDimension($columnID)->setAutoSize(true);
    }

    // Set header for download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="document_report.xlsx"');

    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
}

// End of the PHP script
?>