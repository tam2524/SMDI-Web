<?php
include 'db_config.php'; // Include your DB connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the ID is set and is a valid integer
    if (isset($_POST['id']) && filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
        $id = $_POST['id'];

        // Prepare SQL to update the notification status to 'read'
        $sql = "UPDATE follow_ups SET status = 'read' WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind parameters and execute
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to update notification.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database query preparation failed.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid notification ID.']);
    }
    
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
