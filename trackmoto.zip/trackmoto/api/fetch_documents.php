<?php
include 'db_config.php';

// Sanitize and validate parameters
$searchQuery = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';
$documentTypeFilter = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'both';
$statusFilter = isset($_GET['status']) ? htmlspecialchars($_GET['status']) : 'all';
$sortBy = isset($_GET['sort']) ? htmlspecialchars($_GET['sort']) : 'date_reg';
$sortOrder = isset($_GET['order']) ? strtoupper(htmlspecialchars($_GET['order'])) : 'ASC';
$page = isset($_GET['page']) ? intval($_GET['page']) : 1; // Current page
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10; // Number of records per page

// Validate sorting parameters, only allow specific columns
$validSortColumns = ['customer_name', 'date_reg', 'last_updated'];
if (!in_array($sortBy, $validSortColumns)) {
    $sortBy = 'date_reg'; // Default sorting
}
$sortOrder = ($sortOrder === 'DESC') ? 'DESC' : 'ASC';

// Calculate offset for pagination
$offset = ($page - 1) * $limit;

// Prepare SQL query for counting total records
$countSql = "
    SELECT COUNT(*) as total
    FROM documents d
    LEFT JOIN customers c ON d.customer_id = c.customer_id
    LEFT JOIN document_records r ON r.record_id = c.record_id
    WHERE 
        (d.document_type LIKE ? OR ? = 'both')
        AND (d.status LIKE ? OR ? = 'all')
        AND (CONCAT(c.family_name, ', ', c.first_name, ' ', c.middle_initial) LIKE ?)
";

// Prepare the count query
$countStmt = $conn->prepare($countSql);
if ($countStmt === false) {
    echo json_encode(['error' => 'Failed to prepare SQL statement.']);
    exit;
}

// Bind parameters for counting
$docTypeTerm = ($documentTypeFilter === 'both') ? '%' : $documentTypeFilter;
$statusTerm = ($statusFilter === 'all') ? '%' : $statusFilter;
$searchTerm = "%$searchQuery%";

$countStmt->bind_param('sssss', $docTypeTerm, $docTypeTerm, $statusTerm, $searchTerm, $searchTerm);

// Execute the count query
$countStmt->execute();
$countResult = $countStmt->get_result();
$totalRecords = $countResult->fetch_assoc()['total']; // Total number of records
$totalPages = ceil($totalRecords / $limit); // Calculate total pages

$countStmt->close();

// Prepare SQL query for fetching records
$sql = "
    SELECT d.document_id, d.customer_id, d.document_type, d.document_number, d.status,
           r.date_reg AS date_reg, d.last_updated,
           CONCAT(c.family_name, ', ', c.first_name, ' ', c.middle_initial) AS customer_name
    FROM documents d
    LEFT JOIN customers c ON d.customer_id = c.customer_id
    LEFT JOIN document_records r ON r.record_id = c.record_id
    WHERE 
        (d.document_type LIKE ? OR ? = 'both')
        AND (d.status LIKE ? OR ? = 'all')
        AND (CONCAT(c.family_name, ', ', c.first_name, ' ', c.middle_initial) LIKE ?)
    ORDER BY $sortBy $sortOrder
    LIMIT ? OFFSET ?
";

// Prepare the fetch query
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo json_encode(['error' => 'Failed to prepare SQL statement.']);
    exit;
}

// Bind parameters for fetching records
$stmt->bind_param('sssssii', $docTypeTerm, $docTypeTerm, $statusTerm, $searchTerm, $searchTerm, $limit, $offset);

// Execute and fetch results
$conn->begin_transaction();
try {
    $stmt->execute();
    $result = $stmt->get_result();

    $output = ['html' => '', 'totalPages' => $totalPages];

    if ($result->num_rows > 0) {
        while ($doc = $result->fetch_assoc()) {
            // Escape data for output
            $docId = htmlspecialchars($doc['document_id']);
            $customerId = htmlspecialchars($doc['customer_id']);
            $docType = htmlspecialchars($doc['document_type']);
            $docNumber = htmlspecialchars($doc['document_number']);
            $status = htmlspecialchars($doc['status']);
            $dateReg = htmlspecialchars($doc['date_reg']);
            $lastUpdated = htmlspecialchars($doc['last_updated']);
            $customerName = htmlspecialchars($doc['customer_name']);
            
            $output['html'] .= "<tr data-id='$docId'>
            <td>$docId</td>
            <td>$customerName</td>
            <td>$docType</td>
            <td>$docNumber</td>
            <td>
                <select class='form-select status-dropdown' data-id='$docId'>
                    <option value='On Processing' " . ($status === 'On Processing' ? 'selected' : '') . ">On Processing</option>
                    <option value='Ready for Pick Up' " . ($status === 'Ready for Pick Up' ? 'selected' : '') . ">Ready for Pick Up</option>
                    <option value='Released' " . ($status === 'Released' ? 'selected' : '') . ">Released</option>
                </select>
            </td>
            <td>$dateReg</td>
            <td>$lastUpdated</td>
            <td>
                <button class='btn btn-info notifyButton' data-id='$docId'>Notify</button>
            </td>
        </tr>";
        
        }
    } else {
        $output['html'] = "<tr><td colspan='7'>No records found</td></tr>";
    }

    $stmt->close();
    $conn->commit();

    echo json_encode($output); // Return the output as JSON

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['error' => 'Failed to fetch documents. Error: ' . htmlspecialchars($e->getMessage())]);
}

$conn->close();
?>
