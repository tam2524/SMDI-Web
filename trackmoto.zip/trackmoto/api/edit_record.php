<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recordId = $_POST['record_id'];
    $dateReg = $_POST['date_reg'];
    $familyName = $_POST['family_name'];
    $firstName = $_POST['first_name'];
    $middleInitial = $_POST['middle_initial'];
    $plateNumber = $_POST['plate_number'];
    $mvFile = $_POST['mv_file'];
    $branch = $_POST['branch'];
    $batch = $_POST['batch'];
    $remarks = $_POST['remarks'];
    $encodedBy = $_SESSION['username']; // Assuming session is started and username is set

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Update records table
        $sql = "UPDATE document_records 
                SET date_reg = ?, family_name = ?, first_name = ?, middle_initial = ?, plate_number = ?, mv_file = ?, branch = ?, batch = ?, remarks = ?, action = ? 
                WHERE record_id = ?";
        $actionLog = "Updated document record by " . $encodedBy;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssi", $dateReg, $familyName, $firstName, $middleInitial, $plateNumber, $mvFile, $branch, $batch, $remarks, $actionLog, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update records table: ' . $stmt->error);
        }
        $stmt->close();

        // Update customers table
        $sql = "UPDATE customers 
                SET family_name = ?, first_name = ?, middle_initial = ?, branch = ?, action = ? 
                WHERE customer_id = (SELECT customer_id FROM document_records WHERE record_id = ?)";
        $actionLog = "Updated customer record by " . $encodedBy;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $familyName, $firstName, $middleInitial, $branch, $actionLog, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update customers table: ' . $stmt->error);
        }
        $stmt->close();

        // Update OR/CR document
        $mvFile = empty($mvFile) ? "ND" : $mvFile;
        $stmt = $conn->prepare("UPDATE documents 
                                SET document_number = ?, status = 'On Processing', action = ? 
                                WHERE customer_id = (SELECT customer_id FROM document_records WHERE record_id = ?) 
                                AND document_type = 'OR/CR'");
        $actionLog = "Updated OR/CR document for customer by " . $encodedBy;
        $stmt->bind_param("ssi", $mvFile, $actionLog, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update OR/CR document: ' . $stmt->error);
        }
        $stmt->close();

        // Update LTO Plate Number document
        $plateNumber = empty($plateNumber) ? "ND" : $plateNumber;
        $stmt = $conn->prepare("UPDATE documents 
                                SET document_number = ?, status = 'On Processing', action = ? 
                                WHERE customer_id = (SELECT customer_id FROM document_records WHERE record_id = ?) 
                                AND document_type = 'LTO Plate Number'");
        $actionLog = "Updated LTO Plate Number document for customer by " . $encodedBy;
        $stmt->bind_param("ssi", $plateNumber, $actionLog, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update LTO Plate Number document: ' . $stmt->error);
        }
        $stmt->close();

        // Commit the transaction
        $conn->commit();
        echo json_encode(['status' => 'success', 'message' => 'Record and documents updated successfully.']);
    } catch (Exception $e) {
        // Rollback the transaction if something goes wrong
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Failed to update record. Error: ' . $e->getMessage()]);
    }

    // Close the connection
    $conn->close();
}
?>