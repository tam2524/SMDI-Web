<?php
include 'db_config.php';

if (!isset($_SESSION['username'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

// Get search query and pagination parameters
$searchQuery = isset($_GET['query']) ? $conn->real_escape_string($_GET['query']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$recordsPerPage = 15; // Set the number of records per page to 15
$offset = ($page - 1) * $recordsPerPage;

// Build the SQL query for fetching customers
$query = "SELECT * FROM customers WHERE 1=1";

if ($searchQuery) {
    $query .= " AND (family_name LIKE '%$searchQuery%' OR first_name LIKE '%$searchQuery%' OR middle_initial LIKE '%$searchQuery%')";
}

// Get total records for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM customers WHERE 1=1";

if ($searchQuery) {
    $totalQuery .= " AND (family_name LIKE '%$searchQuery%' OR first_name LIKE '%$searchQuery%' OR middle_initial LIKE '%$searchQuery%')";
}

$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $recordsPerPage);

// Fetch the records for the current page
$query .= " LIMIT $offset, $recordsPerPage";
$result = $conn->query($query);

// Prepare response data
$response = [];
$response['totalPages'] = $totalPages;
$response['customers'] = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response['customers'][] = $row;
    }
} 

echo json_encode($response);

$conn->close();
?>
