<?php 
require_once '../vendor/autoload.php';

$config = require 'api_config.php'; 
$apiKey = $config['apiKey'];
$senderName = $config['senderName'] ?? ''; 

$response = [
    'status' => 'error',
    'message' => 'An unexpected error occurred.'
];

try {
    // Log received POST data
    error_log("Received POST data: " . print_r($_POST, true));

    $contactNumber = $_POST['contactNumber'] ?? ''; 
    $responseMessage = $_POST['responseMessage'] ?? ''; 

    if (empty($contactNumber) || empty($responseMessage)) {
        throw new Exception('Required data missing.');
    }

    $url = 'https://api.semaphore.co/api/v4/messages';
    $data = [
        'apikey' => $apiKey,
        'number' => $contactNumber,
        'message' => $responseMessage,
        'sendername' => $senderName,
        'part' => 1,
        'totalParts' => 1
    ];

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result === FALSE) {
        throw new Exception('Failed to send response.');
    }

    $resultData = json_decode($result, true);

    if (isset($resultData[0]['message_id'])) {
        $response = [
            'status' => 'success',
            'message' => 'Response sent successfully.',
            'message_id' => $resultData[0]['message_id']
        ];
    } else {
        error_log("Full Response: " . print_r($resultData, true));
        $errorMessage = $resultData[0]['message'] ?? 'Unknown error';
        $response = [
            'status' => 'error',
            'message' => 'Failed to send response: ' . $errorMessage
        ];
    }
} catch (Exception $e) {
    $response = [
        'status' => 'error',
        'message' => $e->getMessage()
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
