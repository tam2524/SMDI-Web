<?php
require_once '../vendor/autoload.php'; // Adjust the path as needed

// Load configuration
$config = require 'api_config.php'; // Ensure you have this file with your API key and sender name
$apiKey = $config['apiKey'];
$senderName = $config['senderName']; // Optional: Replace with your sender name or leave out for default

// Get POST data
$notificationId = $_POST['notificationId'] ?? '';
$contactNumber = $_POST['contactNumber'] ?? ''; // This should be the recipient's mobile number
$responseMessage = $_POST['responseMessage'] ?? '';

$response = [
    'status' => 'error',
    'message' => 'An unexpected error occurred.'
];

try {
    // Validate required fields
    if (empty($notificationId) || empty($contactNumber) || empty($responseMessage)) {
        throw new Exception('Required data missing.');
    }

    // Prepare the data for the API request
    $url = 'https://api.semaphore.co/api/v4/messages';
    $data = [
        'apikey' => $apiKey,
        'number' => $contactNumber, // Recipient's mobile number
        'message' => $responseMessage,
        'sendername' => $senderName, // Optional: Include if you have a custom sender name
        'part' => 1,  // Assuming this is the part number of your message
        'totalParts' => 1  // Total parts of your message
    ];

    // Set up the HTTP context
    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    // Log the raw response for debugging
    file_put_contents('debug_log.txt', "Raw Response: " . $result . "\n", FILE_APPEND);

    if ($result === FALSE) {
        throw new Exception('Failed to send response.');
    }

    // Decode the response
    // Decode the response
$resultData = json_decode($result, true);

// Check if decoding was successful and if the response contains data
if (isset($resultData[0]['message_id'])) {
    // Message sent successfully
    $response = [
        'status' => 'success',
        'message' => 'Response sent successfully.',
        'message_id' => $resultData[0]['message_id']
    ];
} else {
    // Log the entire response for better debugging
    file_put_contents('debug_log.txt', "Full Response: " . print_r($resultData, true) . "\n", FILE_APPEND);
    
    // Prepare error message
    $errorMessage = isset($resultData[0]['message']) ? $resultData[0]['message'] : 'Unknown error';
    $response = [
        'status' => 'error',
        'message' => 'Failed to send response: ' . $errorMessage
    ];
}
} catch (Exception $e) {
    $response = [
        'status' => 'error',
        'message' => $e->getMessage()
    ];
}

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>