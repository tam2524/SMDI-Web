<?php
include 'db_config.php';

// Initialize the response array
$response = array();

try {
    // Query to get user counts by month
    $query = "SELECT MONTH(created_at) AS month, COUNT(*) AS userCount FROM users GROUP BY MONTH(created_at)";
    $result = mysqli_query($conn, $query);
    
    $months = [];
    $counts = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $months[] = $row['month'];
        $counts[] = $row['userCount'];
    }

    $response['months'] = $months;
    $response['counts'] = $counts;

    // Query to get total documents by status
    $query = "
        SELECT 
            SUM(CASE WHEN status = 'On Processing' THEN 1 ELSE 0 END) AS processingDocuments,
            SUM(CASE WHEN status = 'Ready for Pick Up' THEN 1 ELSE 0 END) AS readyForPickupDocuments,
            SUM(CASE WHEN status = 'Released' THEN 1 ELSE 0 END) AS releasedDocuments
        FROM documents
    ";
    $result = mysqli_query($conn, $query);
    if (!$result) throw new Exception('Query failed: ' . mysqli_error($conn));
    
    $data = mysqli_fetch_assoc($result);
    
    // Include document counts in the response
    $response['processingDocuments'] = $data['processingDocuments'];
    $response['readyForPickupDocuments'] = $data['readyForPickupDocuments'];
    $response['releasedDocuments'] = $data['releasedDocuments'];

    // Send response
    echo json_encode($response);

} catch (Exception $e) {
    // Error handling
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>
