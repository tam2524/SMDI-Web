<?php
header('Content-Type: application/json');
include 'db_config.php'; 


$customerId = $_GET['customerId'] ?? '';

if ($customerId) {
    $query = "SELECT * FROM motorcycles WHERE customer_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    echo json_encode($result);
} else {
    echo json_encode(['error' => 'No customer ID provided']);
}
?>
