<?php
include 'db_config.php';

// Initialize response array
$response = [
    'status' => 'error',
    'message' => 'An error occurred while fetching the document status.',
    'data' => []
];

// Retrieve input parameter from query string
$documentId = $_GET['document_id'] ?? '';

// Validate input
if (empty($documentId)) {
    $response['message'] = 'Document ID is required.';
    echo json_encode($response);
    exit;
}

// Prepare and execute the query
$sql = "SELECT d.document_id, d.document_type, d.status
        FROM documents d
        WHERE d.document_id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    $response['message'] = 'Failed to prepare the SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param('i', $documentId); // Assuming document_id is an integer
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    // Fetch and return results
    $documents = [];
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }

    if (empty($documents)) {
        $response['message'] = 'No document found with the given ID.';
    } else {
        $response['status'] = 'success';
        $response['message'] = 'Document retrieved successfully.';
        $response['data'] = $documents; // This should contain document information
    }
} else {
    $response['message'] = 'An error occurred while executing the query.';
}

$stmt->close();
$conn->close();

// Return the response
echo json_encode($response);
?>
