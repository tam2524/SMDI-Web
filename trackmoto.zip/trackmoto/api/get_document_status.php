<?php
include 'db_config.php';

// Initialize response array
$response = [
    'status' => 'error',
    'message' => 'An error occurred while fetching the document status.',
    'data' => []
];

// Retrieve input parameters
$lastName = $_POST['lastName'] ?? '';
$firstName = $_POST['firstName'] ?? '';

// Validate input
if (empty($lastName) || empty($firstName)) {
    $response['message'] = 'Last Name and First Name are required.';
    echo json_encode($response);
    exit;
}

// Prepare and execute the query
$sql = "SELECT d.document_id, CONCAT(c.first_name, ' ', c.family_name) AS customer_name, r.date_reg, m.make, m.series, d.document_type, d.document_number, d.status
        FROM customers c
        JOIN document_records r ON c.record_id = r.record_id
        LEFT JOIN motorcycles m ON c.customer_id = m.customer_id
        LEFT JOIN documents d ON c.customer_id = d.customer_id
        WHERE c.family_name = ? AND c.first_name = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    $response['message'] = 'Failed to prepare the SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param('ss', $lastName, $firstName);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    // Fetch and return results
    $documents = [];
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }

    if (empty($documents)) {
        $response['message'] = 'No documents found for the given names.';
    } else {
        $response['status'] = 'success';
        $response['message'] = 'Documents retrieved successfully.';
        $response['data'] = $documents;
    }
} else {
    $response['message'] = 'An error occurred while executing the query.';
}

$stmt->close();
$conn->close();

// Return the response
echo json_encode($response);
?>
