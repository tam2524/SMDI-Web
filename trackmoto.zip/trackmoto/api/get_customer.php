<?php
header('Content-Type: application/json');
include 'db_config.php';


$customerId = $_GET['customerId'] ?? '';

if ($customerId) {
    $customerQuery = "SELECT * FROM customers WHERE customer_id = ?";
    $stmt = $conn->prepare($customerQuery);
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $customerResult = $stmt->get_result()->fetch_assoc();

    $motorcycleQuery = "SELECT * FROM motorcycles WHERE customer_id = ?";
    $stmt = $conn->prepare($motorcycleQuery);
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $motorcycleResult = $stmt->get_result()->fetch_assoc();

    echo json_encode([
        'customer' => $customerResult,
        'motorcycle' => $motorcycleResult
    ]);
} else {
    echo json_encode(['error' => 'No customer ID provided']);
}
?>
