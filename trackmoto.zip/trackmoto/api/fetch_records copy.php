<?php
header('Content-Type: application/json');
include 'db_config.php';

if (!isset($_SESSION['username'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

$query = $_GET['query'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = $_GET['limit'] ?? 10;

$offset = ($page - 1) * $limit;
// Get the sorting parameters from the request
$sortColumn = $_GET['sort'] ?? 'date_reg'; // Default sort column
$sortOrder = $_GET['order'] ?? 'ASC'; // Default sort order

// Modify your SQL query to include sorting
$sql = "SELECT * FROM document_records 
        WHERE date_reg LIKE ? 
        OR family_name LIKE ? 
        OR first_name LIKE ? 
        OR middle_initial LIKE ? 
        OR plate_number LIKE ? 
        OR mv_file LIKE ? 
        OR branch LIKE ? 
        OR batch LIKE ?
        ORDER BY $sortColumn $sortOrder
        LIMIT ?, ?";

$stmt = mysqli_prepare($conn, $sql);
$searchTerm = "%$query%";
mysqli_stmt_bind_param($stmt, "ssssssssii", $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $offset, $limit);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
// Prepare response
$response = [];
$response['records'] = [];

// Get total count of records matching the search criteria
$countSql = "SELECT COUNT(*) as total FROM document_records 
             WHERE date_reg LIKE ? 
             OR family_name LIKE ? 
             OR first_name LIKE ? 
             OR middle_initial LIKE ? 
             OR plate_number LIKE ? 
             OR mv_file LIKE ? 
             OR branch LIKE ? 
             OR batch LIKE ?";

$countStmt = mysqli_prepare($conn, $countSql);
mysqli_stmt_bind_param($countStmt, "ssssssss", $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
mysqli_stmt_execute($countStmt);
$totalCountResult = mysqli_stmt_get_result($countStmt);
$row = mysqli_fetch_assoc($totalCountResult);
$response['total'] = $row['total'];

while ($record = mysqli_fetch_assoc($result)) {
    $response['records'][] = $record;
}

echo json_encode($response);

mysqli_stmt_close($stmt);
mysqli_stmt_close($countStmt);
mysqli_close($conn);
?>
