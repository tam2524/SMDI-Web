<?php
include 'db_config.php';

$id = $_GET['id'] ?? '';

$sql = "SELECT * FROM document_records WHERE record_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($record = mysqli_fetch_assoc($result)) {
    echo json_encode($record);
} else {
    echo json_encode(['error' => 'Record not found']);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
