<?php
// Include your database connection file
include 'api/db_config.php'; // Adjust the path as necessary

// Fetch user actions
$userActionsQuery = "SELECT username, action, action_time FROM user_actions ORDER BY action_time DESC";
$userActionsResult = mysqli_query($conn, $userActionsQuery);

// Fetch login attempts
$loginAttemptsQuery = "SELECT username, attempts, last_attempt FROM login_attempts ORDER BY last_attempt DESC";
$loginAttemptsResult = mysqli_query($conn, $loginAttemptsQuery);

// Check for errors in queries
if (!$userActionsResult || !$loginAttemptsResult) {
    die('Error fetching logs: ' . mysqli_error($conn));
}
?>