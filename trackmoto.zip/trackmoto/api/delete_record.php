<?php
include 'db_config.php';

header('Content-Type: application/json');



$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ids = $_POST['ids'];

    if (empty($ids)) {
        $response['status'] = 'error';
        $response['message'] = 'No IDs provided';
        echo json_encode($response);
        exit;
    }

    $conn->begin_transaction();

    try {
        foreach ($ids as $id) {
            // Get the customer_id from the record before deleting it
            $getCustomerIdQuery = "SELECT customer_id FROM document_records WHERE record_id=?";
            $stmt = $conn->prepare($getCustomerIdQuery);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->bind_result($customer_id);
            $stmt->fetch();
            $stmt->close();

            // Delete documents associated with the record
            if ($customer_id) {
                $deleteDocumentsQuery = "DELETE FROM documents WHERE customer_id=?";
                $stmt = $conn->prepare($deleteDocumentsQuery);
                $stmt->bind_param("i", $customer_id);
                $stmt->execute();
                $stmt->close();
            }

            // Delete record from 'records' table
            $deleteRecordsQuery = "DELETE FROM document_records WHERE record_id=?";
            $stmt = $conn->prepare($deleteRecordsQuery);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();

            // Only delete related motorcycles and customer if a valid customer_id was found
            if ($customer_id) {
                // Delete motorcycles related to this customer
                $deleteMotorcyclesQuery = "DELETE FROM motorcycles WHERE customer_id=?";
                $stmt = $conn->prepare($deleteMotorcyclesQuery);
                $stmt->bind_param("i", $customer_id);
                $stmt->execute();
                $stmt->close();

                // Check if motorcycles were actually deleted
                $checkMotorcyclesQuery = "SELECT COUNT(*) FROM motorcycles WHERE customer_id=?";
                $stmt = $conn->prepare($checkMotorcyclesQuery);
                $stmt->bind_param("i", $customer_id);
                $stmt->execute();
                $stmt->bind_result($motorcycleCount);
                $stmt->fetch();
                $stmt->close();

                if ($motorcycleCount > 0) {
                    throw new Exception('Some motorcycles could not be deleted.');
                }

                // Delete customer if no records left
                $checkRecordsQuery = "SELECT COUNT(*) FROM document_records WHERE customer_id=?";
                $stmt = $conn->prepare($checkRecordsQuery);
                $stmt->bind_param("i", $customer_id);
                $stmt->execute();
                $stmt->bind_result($count);
                $stmt->fetch();
                $stmt->close();

                if ($count == 0) {
                    $deleteCustomerQuery = "DELETE FROM customers WHERE customer_id=?";
                    $stmt = $conn->prepare($deleteCustomerQuery);
                    $stmt->bind_param("i", $customer_id);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }

        $conn->commit();

        $response['status'] = 'success';
        $response['message'] = 'Records and related data deleted successfully';
    } catch (Exception $e) {
        $conn->rollback();
        $response['status'] = 'error';
        $response['message'] = 'Failed to delete records: ' . $e->getMessage();
    }

    $conn->close();

    echo json_encode($response);
}
?>
