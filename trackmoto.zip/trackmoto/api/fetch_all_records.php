<?php
header('Content-Type: application/json');
include 'db_config.php';

$query = $_GET['query'] ?? '';

// Prepare the SQL query for fetching all records
$sql = "SELECT * FROM document_records 
        WHERE date_reg LIKE ? 
        OR family_name LIKE ? 
        OR first_name LIKE ? 
        OR middle_initial LIKE ? 
        OR plate_number LIKE ? 
        OR mv_file LIKE ? 
        OR branch LIKE ? 
        OR batch LIKE ?";

$stmt = mysqli_prepare($conn, $sql);
$searchTerm = "%$query%";
mysqli_stmt_bind_param($stmt, "ssssssss", $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
 mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Prepare response
$response = [];
$response['records'] = [];

while ($record = mysqli_fetch_assoc($result)) {
    $response['records'][] = $record;
}

echo json_encode($response);

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>