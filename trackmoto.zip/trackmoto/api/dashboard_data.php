<?php
include 'db_config.php';

// Initialize the response array
$response = array();

try {
    // Query to get total users
    $query = "SELECT COUNT(*) AS totalUsers FROM users";
    $result = mysqli_query($conn, $query);
    if (!$result) throw new Exception('Query failed: ' . mysqli_error($conn));
    $data = mysqli_fetch_assoc($result);
    $response['totalUsers'] = $data['totalUsers'];

    // Query to get total customers
    $query = "SELECT COUNT(*) AS totalCustomers FROM customers";
    $result = mysqli_query($conn, $query);
    if (!$result) throw new Exception('Query failed: ' . mysqli_error($conn));
    $data = mysqli_fetch_assoc($result);
    $response['totalCustomers'] = $data['totalCustomers'];

    // Query to get total documents
    $query = "SELECT COUNT(*) AS totalDocuments FROM documents";
    $result = mysqli_query($conn, $query);
    if (!$result) throw new Exception('Query failed: ' . mysqli_error($conn));
    $data = mysqli_fetch_assoc($result);
    $response['totalDocuments'] = $data['totalDocuments'];

    // Query to get total documents by status
    $query = "
        SELECT 
            SUM(CASE WHEN status = 'On Processing' THEN 1 ELSE 0 END) AS processingDocuments,
            SUM(CASE WHEN status = 'Ready for Pick Up' THEN 1 ELSE 0 END) AS readyForPickupDocuments,
            SUM(CASE WHEN status = 'Released' THEN 1 ELSE 0 END) AS releasedDocuments
        FROM documents
    ";
    $result = mysqli_query($conn, $query);
    if (!$result) throw new Exception('Query failed: ' . mysqli_error($conn));
    $data = mysqli_fetch_assoc($result);
    
    // Add the status counts to the response
    $response['processingDocuments'] = $data['processingDocuments'];
    $response['readyForPickupDocuments'] = $data['readyForPickupDocuments'];
    $response['releasedDocuments'] = $data['releasedDocuments'];

    // Send response
    echo json_encode($response);

} catch (Exception $e) {
    // Error handling
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>
