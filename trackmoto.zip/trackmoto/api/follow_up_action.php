<?php
header('Content-Type: application/json');
require_once 'db_config.php'; // Include your database connection file

// Retrieve POST data
$documentId = $_POST['documentId'] ?? '';
$contactNumber = $_POST['contactNumber'] ?? '';
$followUpMessage = $_POST['followUpMessage'] ?? '';
$customerName = $_POST['customerName'] ?? ''; // Added customerName field

// Validate inputs
if (empty($documentId) || empty($contactNumber) || empty($followUpMessage) || empty($customerName)) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit;
}

// Prepare and execute query
$query = "INSERT INTO follow_ups (document_id, customer_name, contact_number, message) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo json_encode(['status' => 'error', 'message' => 'Database prepare error.']);
    exit;
}

$stmt->bind_param('ssss', $documentId, $customerName, $contactNumber, $followUpMessage);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Follow-up data successfully saved.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to save follow-up data.']);
}

$stmt->close();
$conn->close();
?>
