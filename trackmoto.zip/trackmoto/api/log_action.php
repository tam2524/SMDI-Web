<?php
include 'api/db_config.php'; // Include your database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the AJAX request
    $username = $_POST['username'];
    $action = $_POST['action'];
    
    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO user_actions (username, action, action_time) VALUES (?, ?, ?)");
    $actionTime = date('Y-m-d H:i:s'); // Current timestamp
    $stmt->bind_param("sss", $username, $action, $actionTime);
    
    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }
    
    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>