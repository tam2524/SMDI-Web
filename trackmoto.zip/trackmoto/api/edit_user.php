<?php
include 'db_config.php';



$user_id = $_POST['user_id'];
$username = $_POST['username'];
$position = $_POST['position'];

$sql = "UPDATE users 
        SET username = ?, position = ?
        WHERE id = ?";

$stmt = mysqli_prepare($conn, $sql);


mysqli_stmt_bind_param($stmt, "ssi", $username, $position, $user_id);


if (mysqli_stmt_execute($stmt)) {
    echo json_encode(['status' => 'success', 'message' => 'Record updated successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update record.']);
}


mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
