<?php
include 'db_config.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize input data
    $customerId = filter_input(INPUT_POST, 'customer_id', FILTER_SANITIZE_NUMBER_INT);
    $familyName = htmlspecialchars(trim(filter_input(INPUT_POST, 'familyName', FILTER_DEFAULT)), ENT_QUOTES);
    $firstName = htmlspecialchars(trim(filter_input(INPUT_POST, 'firstName', FILTER_DEFAULT)), ENT_QUOTES);
    $middleName = htmlspecialchars(trim(filter_input(INPUT_POST, 'middleName', FILTER_DEFAULT)), ENT_QUOTES);
    $engineNo = htmlspecialchars(trim(filter_input(INPUT_POST, 'engineNo', FILTER_DEFAULT)), ENT_QUOTES);
    $chassisNo = htmlspecialchars(trim(filter_input(INPUT_POST, 'chassisNo', FILTER_DEFAULT)), ENT_QUOTES);
    $make = htmlspecialchars(trim(filter_input(INPUT_POST, 'make', FILTER_DEFAULT)), ENT_QUOTES);
    $yearModel = htmlspecialchars(trim(filter_input(INPUT_POST, 'yearModel', FILTER_DEFAULT)), ENT_QUOTES);
    $series = htmlspecialchars(trim(filter_input(INPUT_POST, 'series', FILTER_DEFAULT)), ENT_QUOTES);
    $bodyType = htmlspecialchars(trim(filter_input(INPUT_POST, 'bodyType', FILTER_DEFAULT)), ENT_QUOTES);
    $denomination = htmlspecialchars(trim(filter_input(INPUT_POST, 'denomination', FILTER_DEFAULT)), ENT_QUOTES);
    $datePurchase = htmlspecialchars(trim(filter_input(INPUT_POST, 'datePurchase', FILTER_DEFAULT)), ENT_QUOTES);
    $encodedBy = $_SESSION['username']; // Assuming session is started and username is set

    // Debug: Log incoming data
    error_log("Received data: customerId=$customerId, familyName=$familyName, firstName=$firstName, middleName=$middleName, engineNo=$engineNo, chassisNo=$chassisNo, make=$make, yearModel=$yearModel, series=$series, bodyType=$bodyType, denomination=$denomination, datePurchase=$datePurchase");

    if (empty($customerId) || empty($familyName) || empty($firstName) || empty($middleName) || empty($engineNo) || empty($chassisNo) || empty($make) || empty($yearModel) || empty($series) || empty($bodyType) || empty($denomination) || empty($datePurchase)) {
        $response['status'] = 'error';
        $response['message'] = 'Missing required fields';
        echo json_encode($response);
        exit;
    }

    $conn->begin_transaction();

    try {
        // Update customer information
        $updateCustomerQuery = "UPDATE customers SET family_name=?, first_name=?, middle_initial=?, action=? WHERE customer_id=?";
        $actionLog = "Updated customer record by " . $encodedBy;
        $stmt = $conn->prepare($updateCustomerQuery);
        if ($stmt === false) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        $stmt->bind_param("ssssi", $familyName, $firstName, $middleName, $actionLog, $customerId);
        $stmt->execute();
        $stmt->close();

        // Check if motorcycle record exists
        $checkMotorcycleQuery = "SELECT COUNT(*) FROM motorcycles WHERE customer_id=?";
        $stmt = $conn->prepare($checkMotorcycleQuery);
        if ($stmt === false) {
            throw new Exception('Prepare statement failed: ' . $conn->error);
        }
        $stmt->bind_param("i", $customerId);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        // Insert or update motorcycle record
        if ($count > 0) {
            $updateMotorcycleQuery = "UPDATE motorcycles SET engine_no=?, chassis_no=?, make=?, year_model=?, series=?, body_type=?, denomination=?, date_purchase=?, action=? WHERE customer_id=?";
            $actionLog = "Updated motorcycle record for customer ID " . $customerId . " by " . $encodedBy;
            $stmt = $conn->prepare($updateMotorcycleQuery);
            if ($stmt === false) {
                throw new Exception('Prepare statement failed: ' . $conn->error);
            }
            $stmt->bind_param("ssssssssii", $engineNo, $chassisNo, $make, $yearModel, $series, $bodyType, $denomination, $datePurchase, $actionLog, $customerId);
        } else {
            $insertMotorcycleQuery = "INSERT INTO motorcycles (engine_no, chassis_no, make, year_model, series, body_type, denomination, date_purchase , customer_id, action) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $actionLog = "Inserted new motorcycle record for customer ID " . $customerId . " by " . $encodedBy;
            $stmt = $conn->prepare($insertMotorcycleQuery);
            if ($stmt === false) {
                throw new Exception('Prepare statement failed: ' . $conn->error);
            }
            $stmt->bind_param("ssssssssis", $engineNo, $chassisNo, $make, $yearModel, $series, $bodyType, $denomination, $datePurchase, $customerId, $actionLog);
        }

        $stmt->execute();
        $stmt->close();

        $conn->commit();

        $response['status'] = 'success';
        $response['message'] = 'Record updated successfully';
    } catch (Exception $e) {
        $conn->rollback();
        $response['status'] = 'error';
        $response['message'] = 'Failed to update record: ' . $e->getMessage();
    }

    $conn->close();

    echo json_encode($response);
}
?>