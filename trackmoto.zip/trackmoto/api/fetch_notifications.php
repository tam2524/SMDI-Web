<?php
include 'db_config.php'; // Include your DB connection

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Query to fetch all notifications
    $sqlAll = "SELECT * FROM follow_ups";
    $resultAll = $conn->query($sqlAll);

    $notifications = [];
    if ($resultAll) {
        while ($row = $resultAll->fetch_assoc()) {
            $notifications[] = $row; // Add each notification to the array
        }
    }

    // Query to count unread notifications
    $sqlUnread = "SELECT COUNT(*) as unreadCount FROM follow_ups WHERE status = 'unread'";
    $resultUnread = $conn->query($sqlUnread);
    $unreadCount = $resultUnread ? $resultUnread->fetch_assoc()['unreadCount'] : 0;

    echo json_encode([
        'status' => 'success',
        'data' => $notifications,
        'unreadCount' => $unreadCount
    ]);
    
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
