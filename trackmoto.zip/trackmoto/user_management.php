<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TRACK MO'TO | User Management</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/styles.css">
        <!-- Scripts -->
           <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
           <script src="js/user_management.js"></script>

               <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>

    </head>
<body>
 <!-- Sidebar -->
    <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="notificationDropdown-item" href="admin_notifications.php">See All notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
             <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="user_management.php">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_records.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>
    <!-- Main Content -->
    <div class="smdi-main-content">
        <!-- Toggle Button -->
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
          <button id="sidebarToggle" class="btn btn-custom-toggle">
            &#9776; <!-- Unicode character for hamburger icon -->
          </button>
        </header>

        <main class="container mt-5">
            <div class="container-fluid py-5">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Users</h5>
                        <button class="btn btn-primary text-white mb-3" data-bs-toggle="modal" data-bs-target="#addUserModal">Add New User</button>
                        <button id="printButton" class="btn btn-primary text-white mb-3">Print Selected</button>
                         <button id="deleteSelectedButton" class="btn btn-primary text-white mb-3">Delete Selected</button>
                         
                        
        <!-- Search and Sort Options -->
        <div class="mb-3 d-flex">
            <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
           
        </div>
        <table id="UserTable" class="table table-striped">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>Username</th>
                    <th>Position</th>
                    <th>Created At</th>
                    <th class="no-print">Actions</th>
                </tr>
            </thead>
            <tbody id="UserTableBody">
        
            </tbody>
        </table>
        
            </div>
                </div>
            </div>
        
        
        <!-- Add User Modal -->
        <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div id="errorMessage" class="alert alert-danger" style="display: none;"></div>
                        <div id="successMessage" class="alert alert-success" style="display: none;"></div>
                        <form id="addUserForm" action="add_User.php" method="post">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="position" class="form-label">Position</label>
                                    <select class="form-select" id="role" name="position" required>
                                        <option value="" disabled selected>Select role</option>
                                        <option value="Staff">Staff</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary text-white">Add User</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        <!-- Edit User Modal -->
        <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editUserForm">
                            <input type="hidden" id="editUserId" name="user_id">
                            <div class="mb-3">
                                <label for="editUsername" class="form-label">Username</label>
                                <input type="text" class="form-control" id="editUsername" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="editPosition" class="form-label">Position</label>
                                <input type="text" class="form-control" id="editPosition" name="position" required>
                            </div>
                            <!-- Add Reset Password Button -->
                            <button type="button" class="btn btn-primary text-white" id="resetPasswordButton">Reset Password</button>
                            <button type="submit" class="btn btn-primary text-white">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        

            <!-- Success Modal -->
            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title" id="successModalLabel">
                                <i class="bi bi-check-circle"></i> Success
                            </h5>
                        </div>
                        <div class="modal-body" id="successMessage">
                            <!-- Success message will be displayed here -->
                            <p>Your changes have been saved successfully!</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        
            <!-- Confirmation Modal -->
            <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationModalLabel">Confirm Deletion</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete this User?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="confirmDeleteBtn" class="btn btn-primary text-white">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        <!-- Duplicate Error Modal -->
        <div class="modal fade" id="duplicateErrorModal" tabindex="-1" aria-labelledby="duplicateErrorModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="duplicateErrorModalLabel">Duplicate User!</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p id="duplicateErrorMessage">A User with this name already exists.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Warning Modal -->
        <div class="modal fade" id="warningModal" tabindex="-1" role="dialog" aria-labelledby="warningModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="warningModalLabel">Warning</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        
              </div>
              <div class="modal-body">
                <p id="warningMessage"></p>
              </div>
            </div>
          </div>
        </div>
        <!-- Reset Password Modal -->
        <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="resetPasswordModalLabel">Reset Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="resetPasswordForm">
                            <input type="hidden" id="resetUserId" name="user_id">
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="newPassword" name="new_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirmPassword" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirmPassword" name="confirm_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary text-white">Reset Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </main>

    <div class="smdi-overlay"></div>


</body>
</html>
