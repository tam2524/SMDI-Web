<?php 
include 'api/auth.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRACK MO'TO | Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <!-- Scripts -->
 <!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script src="js/admin_dashboard.js"></script>

</head>

<body>
    <!-- Sidebar -->
    <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="notificationDropdown-item" href="admin_notifications.php">See All notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
             <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="user_management.php">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_records.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="smdi-main-content">
        <!-- Toggle Button -->
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
            <button id="sidebarToggle" class="btn btn-custom-toggle">
                &#9776; <!-- Unicode character for hamburger icon -->
            </button>
        </header>

        <main class="container mt-5">
            <h1 class="mb-4">Admin Dashboard</h1>
            <div class="row">
                <div class="col-md-12">
                    <div class="card-group">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Total Users</h5>
                                <p class="card-text" id="totalUsers">0</p>
                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Total Customers</h5>
                                <p class="card-text" id="totalCustomers">0</p>
                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Total Documents</h5>
                                <p class="card-text" id="totalDocuments">0</p>
                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Processing</h5>
                                <p class="card-text" id="processingDocuments">0</p>
                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Released</h5>
                                <p class="card-text" id="releasedDocuments">0</p>
                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">Ready for Pickup</h5>
                                <p class="card-text" id="readyForPickupDocuments">0</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Chart -->
            <div class="row mt-5">
    <div class="col-md-6">
        <canvas id="userChart"></canvas>
    </div>
    <div class="col-md-6 d-flex justify-content-center align-items-center">
        <canvas id="documentChart" ></canvas> 
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-12">
        <h2>Login Attempts</h2>
        <table class="table table-striped" id="loginAttemptsTable">
            <thead>
                <tr>
                <th>Username</th>
                    <th>Attempts</th>
                    <th>Last Attempts</th>                
                </tr>
            </thead>
            <tbody>
                <!-- Action logs will be dynamically loaded here -->
            </tbody>
        </table>
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-12">
        <h2>Action Logs</h2>
        <table class="table table-striped" id="actionLogsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Status</th>
                    <th>Updated By</th>
                    <th>Last Updated</th>
                    <th>Source Table</th> <!-- New column for the source table -->
                </tr>
            </thead>
            <tbody>
                <!-- Action logs will be dynamically loaded here -->
            </tbody>
        </table>
    </div>
</div>

        </main>
           <div class="smdi-overlay"></div>


</body>

</html>