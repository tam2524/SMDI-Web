<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRACK MO'TO</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/staff_documents.js"></script>

    <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
</head>

<body>
     <!-- Sidebar -->
    <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="notificationDropdown-item" href="admin_notifications.php">See All notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
             <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="user_management.php">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_records.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="admin_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>
    <!-- Main Content -->
    <div class="smdi-main-content">
        <!-- Toggle Button -->
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
            <button id="sidebarToggle" class="btn btn-custom-toggle">
                &#9776; <!-- Unicode character for hamburger icon -->
            </button>
        </header>

        <main class="container mt-5">
            <div class="container-fluid py-5">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Document Status</h5>

                        <!-- Filters and Search -->
                        <div class="mb-3 d-flex">
                            <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
                            <div class="dropdown">
                                <button class="btn btn-primary text-white dropdown-toggle" type="button"
                                    id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Sort by
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                                    <li><a class="dropdown-item" href="#" data-sort="familyName">Family Name (A-Z)</a></li>
                                    <li><a class="dropdown-item" href="#" data-sort="dateReg">Date Registered</a></li>
                                    <li><a class="dropdown-item" href="#" data-sort="lastUpdated">Last Updated</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Table of Documents -->
                        <div class="table-responsive">
                            <table id="DocumentTable" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th data-column="document_id">ID</th>
                                        <th data-column="customer_name">Customer Name</th>
                                        <th data-column="document_type">Document Type</th>
                                        <th data-column="document_number">Document Number</th>
                                        <th>Status</th>
                                        <th data-column="date_reg">Date Registered</th>
                                        <th data-column="last_updated">Date Updated</th>
                                    </tr>
                                </thead>
                                <tbody id="DocumentTableBody">
                                    <!-- Rows will be populated here by JavaScript -->
                                </tbody>
                            </table>

                            <!-- Pagination Controls -->
                            <nav aria-label="Page navigation">
                                <ul id="DocumentsPaginationControls" class="pagination">
                                    <li id="prevPage" class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                    </li>
                                    <li id="nextPage" class="page-item">
                                        <a class="page-link" href="#">Next</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Update Status Modal -->
            <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="updateStatusModalLabel">Update Document Status</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="updateStatusForm">
                                <input type="hidden" id="documentId" name="documentId">
                                <div class="mb-3">
                                    <label for="documentTypeSelect" class="form-label">Document Type</label>
                                    <select id="documentTypeSelect" name="documentType" class="form-select" required>
                                        <option value="orcr">OR/CR</option>
                                        <option value="lto">LTO Plate Number</option>
                                    </select>
                                </div>
                                <div class="mb-3" id="mvFileNumberDiv">
                                    <label for="mvFileNumber" class="form-label">MV File Number</label>
                                    <input type="text" class="form-control" id="mvFileNumber" name="mvFileNumber">
                                </div>
                                <div class="mb-3" id="plateNumberDiv">
                                    <label for="plateNumber" class="form-label">Plate Number</label>
                                    <input type="text" class="form-control" id="plateNumber" name="plateNumber">
                                </div>
                                <div class="mb-3">
                                    <label for="statusSelect" class="form-label">Status</label>
                                    <select id="statusSelect" name="status" class="form-select" required>
                                        <option value="on_processing">On Processing</option>
                                        <option value="ready_for_pick_up">Ready for Pick Up</option>
                                        <option value="released">Released</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary text-white">Update Status</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

           <!-- Notify Customer Modal -->
           <div class="modal fade" id="notifyCustomerModal" tabindex="-1" aria-labelledby="notifyCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notifyCustomerModalLabel">Notify Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="notificationForm">
                    <div class="mb-3">
                        <label for="contactNumber" class="form-label">Contact Number</label>
                        <input type="text" class="form-control" id="contactNumber" placeholder="Enter contact number" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Notification</button>
                </form>
            </div>
        </div>
    </div>
</div>



            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <p id="successMessageText" class="mb-0">Status updated successfully.</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <div class="smdi-overlay"></div>
    </div>
</body>

</html>
