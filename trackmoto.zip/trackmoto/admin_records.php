<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRACK MO'TO</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/styles.css">
    <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
    <script src="js/staff_dashboard.js"></script>
</head>
<body>
   <!-- Sidebar -->
    <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="notificationDropdown-item" href="admin_notifications.php">See All notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
             <li class="nav-item">
                <a class="nav-link smdi-nav-link " href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="user_management.php">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="admin_records.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="smdi-main-content">
        <!-- Toggle Button -->
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
            <button id="sidebarToggle" class="btn btn-custom-toggle">
                &#9776; <!-- Unicode character for hamburger icon -->
            </button>
        </header>

        <main class="container mt-5">
            <div class="container-fluid py-5">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Records</h5>
                        <button class="btn btn-primary text-white mb-3" data-bs-toggle="modal" data-bs-target="#addRecordModal">Add New Record</button>
                        <button id="printButton" class="btn btn-primary text-white mb-3">Print Masterlists</button>
                        <button id="printLabelsButton" class="btn btn-primary text-white mb-3">Print Labels</button>
                        
                        <!-- Search and Sort Options -->
                        <div class="mb-3 d-flex">
                            <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
                            <div class="dropdown">
                                <button class="btn btn-primary text-white dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Sort by
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                                    <li><a class="dropdown-item" href="#" data-sort="familyName">Family Name (A-Z)</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Table of Records -->
                        <div class="table-responsive">
                        <table id="RecordTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="selectAll"></th>
                                    <th>Date Registered</th>
                                    <th>Family Name</th>
                                    <th>First Name</th>
                                    <th>Middle Initial</th>
                                    <th>Plate Number</th>
                                    <th>MV File</th>
                                    <th>Branch</th>
                                    <th>Batch</th>
                                    <th>Remarks</th>
                                    <th class="no-print">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="RecordTableBody">
                            </tbody>
                            </table>
                           
                        <!-- Pagination Controls -->
                        <nav aria-label="Page navigation">
                            <ul id="DocumentsPaginationControls" class="pagination">
                                <li id="prevPage" class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                </li>
                                <li id="nextPage" class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                        </div>
                    </div>
                </div>
            </div>

           <!-- Add Record Modal -->
<!-- Add Record Modal -->
<div class="modal fade" id="addRecordModal" tabindex="-1" aria-labelledby="addRecordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addRecordModalLabel">Add Record</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div id="errorMessage" class="alert alert-danger" style="display: none;"></div>
                <div id="successMessage" class="alert alert-success" style="display: none;"></div>
                
                <form id="addRecordForm" action="add_Record.php" method="post">
                    <!-- Step 1: Basic Information -->
                    <div class="form-step" id="step1">
                        <h6>Step 1: Basic Information</h6>
                        <div class="row">
                            <small style="font-size: 10px; color: red;"> ND if OR/CRE - LTO PLATE NUMBER is not available</small>
                            <div class="col-md-6 mb-3">
                                <label for="datereg" class="form-label">Date Registered</label>
                                <input type="text" class="form-control" id="datereg" name="date_reg" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="familyName" class="form-label">Family Name</label>
                                <input type="text" class="form-control" id="familyName" name="family_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="firstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="firstName" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="middleInitial" class="form-label">Middle Initial</label>
                                <input type="text" class="form-control" id="middleInitial" name="middle_initial" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="plateNumber" class="form-label">Plate Number</label>
                                <input type="text" class="form-control" id="plateNumber" name="plate_number" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="mvFile" class="form-label">MV File</label>
                                <input type="text" class="form-control" id="mvFile" name="mv_file" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="branch" class="form-label">Branch</label>
                                <input type="text" class="form-control" id="branch" name="branch" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="batch" class="form-label">Batch</label>
                                <input type="text" class="form-control" id="batch" name="batch" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="remarks" class="form-label">Remarks</label>
                                <input type="text" class="form-control" id="remarks" name="remarks" required>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-primary text-white" id="nextStep1">Next</button>
                        </div>
                    </div>

                    <!-- Step 2: Motorcycle Details -->
                    <div class="form-step d-none" id="step2">
                        <h6>Step 2: Motorcycle Details</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="engineNo" class="form-label">Engine Number</label>
                                <input type="text" class="form-control" id="engineNo" name="engineNo" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="chassisNo" class="form-label">Chassis Number</label>
                                <input type="text" class="form-control" id="chassisNo" name="chassisNo" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="make" class="form-label">Make</label>
                                <input type="text" class="form-control" id="make" name="make" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="yearModel" class="form-label">Year Model</label>
                                <input type="text" class="form-control" id="yearModel" name="yearModel" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="series" class="form-label">Series</label>
                                <input type="text" class="form-control" id="series" name="series" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="bodyType" class="form-label">Body Type</label>
                                <input type="text" class="form-control" id="bodyType" name="bodyType" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="denomination" class="form-label">Denomination</label>
                                <input type="text" class="form-control" id="denomination" name="denomination" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="datePurchase" class="form-label">Date of Purchase</label>
                                <input type="date" class="form-control" id="datePurchase" name="datePurchase" required>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-secondary text-white" id="prevStep2">Back</button>
                            <button type="button" class="btn btn-primary text-white" id="nextStep2">Next</button>
                        </div>
                    </div>

                    <!-- Step 3: Confirmation -->
                    <div class="form-step d-none" id="step3">
                        <h6>Step 3: Confirm Submission</h6>
                        <p>Please review your details before submitting:</p>
                        <ul>
                            <li><strong>Date Registered:</strong> <span id="confirmDateReg"></span></li>
                            <li><strong>Family Name:</strong> <span id="confirmFamilyName"></span></li>
                            <li><strong>First Name:</strong> <span id="confirmFirstName"></span></li>
                            <li><strong>Middle Initial:</strong> <span id="confirmMiddleInitial"></span></li>
                            <li><strong>Plate Number:</strong> <span id="confirmPlateNumber"></span></li>
                            <li><strong>MV File:</strong> <span id="confirmMVFile"></span></li>
                            <li><strong>Branch:</strong> <span id="confirmBranch"></span></li>
                            <li><strong>Batch:</strong> <span id="confirmBatch"></span></li>
                            <li><strong>Remarks:</strong> <span id="confirmRemarks"></span></li>
                            <li><strong>Engine Number:</strong> <span id="confirmEngineNo"></span></li>
                            <li><strong>Chassis Number:</strong> <span id="confirmChassisNo"></span></li>
                            <li><strong>Make:</strong> <span id="confirmMake"></span></li>
                            <li><strong>Year Model:</strong> <span id="confirmYearModel"></span></li>
                            <li><strong>Series:</strong> <span id="confirmSeries"></span></li>
                            <li><strong>Body Type:</strong> <span id="confirmBodyType"></span></li>
                            <li><strong>Denomination:</strong> <span id="confirmDenomination"></span></li>
                            <li><strong>Date of Purchase:</strong> <span id="confirmDatePurchase"></span></li>
                        </ul>
                        <div class="text-end">
                            <button type="button" class="btn btn-secondary text-white" id="prevStep3">Back</button>
                            <button type="submit" class="btn btn-primary text-white">Add Record</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

            <!-- Edit Modal -->
            <div class="modal fade" id="editRecordModal" tabindex="-1" aria-labelledby="editRecordModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editRecordModalLabel">Edit Record</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="editRecordForm" action="edit_Record.php" method="post">
                                <input type="hidden" id="editRecordId" name="record_id">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="editDatereg" class="form-label">DateReg</label>
                                        <input type="text" class="form-control" id="editDatereg" name="date_reg">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editFamilyName" class="form-label">Family Name</label>
                                        <input type="text" class="form-control" id="editFamilyName" name="family_name" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editFirstName" class="form-label">First Name</label>
                                        <input type="text" class="form-control" id="editFirstName" name="first_name" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editMiddleInitial" class="form-label">Middle Initial</label>
                                        <input type="text" class="form-control" id="editMiddleInitial" name="middle_initial" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editPlateNumber" class="form-label">Plate Number</label>
                                        <input type="text" class="form-control" id="editPlateNumber" name="plate_number" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="editMvFile" class="form-label">MV File</label>
                                        <input type="text" class="form-control" id="editMvFile" name="mv_file" required>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="editBranch" class="form-label">Branch</label>
                                        <input type="text" class="form-control" id="editBranch" name="branch" required>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="editBatch" class="form-label">Batch</label>
                                        <input type="text" class="form-control" id="editBatch" name="batch" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editRemarks" class="form-label">Remarks</label>
                                        <input type="text" class="form-control" id="editRemarks" name="remarks" required>
                                    </div>
                                </div>
                                <div class="text-end"> 
                                    <button type="submit" class="btn text-white btn-primary">Save Changes</button>
                                </div>
                            </form> 
                        </div>
                    </div>
                </div>
            </div>

            <!-- Success Modal -->
            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title" id="successModalLabel">
                                <i class="bi bi-check-circle"></i> Success
                            </h5>
                        </div>
                        <div class="modal-body" id="successMessage">
                            <!-- Success message will be displayed here -->
                            <p>Your changes have been saved successfully!</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Confirmation Modal -->
            <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationModalLabel">Confirm Deletion</h5>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete this record?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="confirmDeleteBtn" class="btn btn-primary text-white">Delete</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Duplicate Error Modal -->
            <div class="modal fade" id="duplicateErrorModal" tabindex="-1" aria-labelledby="duplicateErrorModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="duplicateErrorModalLabel">Duplicate Record!</h5>
                        </div>
                        <div class="modal-body">
                            <p id="duplicateErrorMessage">A record with this name already exists.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Warning Modal -->
            <div class="modal fade" id="warningModal" tabindex="-1" role="dialog" aria-labelledby="warningModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="warningModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p id="warningMessage"></p>
                        </div>
                    </div>
                </div>
            </div>

        </main>

        <div class="smdi-overlay"></div>
    </div>
</body>
</html>
