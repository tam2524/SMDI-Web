$(document).ready(function () {
    // Initial fetch and set up polling for notifications
    fetchAndUpdateDropdownNotifications();
    fetchAndUpdateNotifications(); // Initial fetch for table notifications
    setInterval(fetchAndUpdateDropdownNotifications, 1000); // Poll every 1 second
    setInterval(fetchAndUpdateNotifications, 1000); // Poll every 1 second for the table

    // Function to toggle sidebar
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    // Event listener for sidebar toggle button
    $('#sidebarToggle').on('click', toggleSidebar);

    // Function to fetch and update notifications for the table
    function fetchAndUpdateNotifications() {
        $.ajax({
            url: 'api/get_follow_up_notifications.php',
            method: 'GET',
            dataType: 'json',   
            success: function (response) {
                var html = '';
                if (response.status === 'success') {
                    response.data.forEach(function (notification) {
                        html += `
                            <tr class="email-item ${notification.is_read === 0 ? 'unread' : ''}" data-id="${notification.id}">
                                <td>${notification.id}</td>
                                <td>${notification.customer_name}</td>
                                <td>${notification.contact_number}</td>
                                <td>${notification.message}</td>
                                <td>${notification.document_name || 'Not Available'}</td>
                                <td>${notification.document_status || 'Not Available'}</td>
                                <td><button class="btn btn-primary text-white respond-btn">Respond</button></td>
                            </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="7">' + response.message + '</td></tr>';
                }
                $('#notificationsTable').html(html);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching notifications:', xhr.status, error);
                $('#errorModal #errorMessageText').text('An error occurred while fetching notifications.');
                $('#errorModal').modal('show');
            }
        });
    }

    // Function to fetch and update dropdown notifications
    function fetchAndUpdateDropdownNotifications() {
        $.ajax({
            url: 'api/fetch_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                var notificationsList = $('#notificationsList');
                var notificationCount = $('#notificationCount');

                notificationsList.empty(); // Clear previous notifications
                if (data.length > 0) {
                    data.forEach(function(notification) {
                        notificationsList.append(
                            `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                            `${notification.customer_name}: ${notification.message}` +
                            '</a></li>'
                        );
                    });
                    notificationCount.text(data.length);
                } else {
                    notificationsList.append('<li><a class="notificationDropdown-item" href="#">See All Notifications</a></li>');
                    notificationCount.text('0');
                }
            },
            error: function() {
                console.error('Failed to load notifications');
                $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
                $('#notificationCount').text('0');
            }
        });
    }

    // Handle dropdown item click
    $(document).on('click', '.notificationDropdown-item', function(e) {
        e.preventDefault();
        var notificationId = $(this).data('id');

        // AJAX request to mark notification as read
        $.ajax({
            url: 'api/mark_notification_read.php',
            type: 'POST',
            data: { id: notificationId },
            success: function() {
                var notificationCount = $('#notificationCount');
                var currentCount = parseInt(notificationCount.text(), 10);
                
                // Decrease the notification count
                if (currentCount > 0) {
                    notificationCount.text(currentCount - 1);
                }
                $(`a[data-id="${notificationId}"]`).parent().remove();
            },
            error: function() {
                console.error('Failed to mark notification as read');
            }
        });

        // Redirect to staff_notifications.php with the notification ID in the URL
        window.location.href = 'staff_notifications.php?id=' + notificationId;
    });

    // Event listener for respond button
$(document).on('click', '.respond-btn', function () {
    var row = $(this).closest('tr');
    var id = row.data('id');
    var contactNumber = row.find('td').eq(2).text();
    var documentStatus = row.find('td').eq(5).text();
    var documentName = row.find('td').eq(4).text();

    // Prepare the response message based on document status
    var responseMessage = `Good day! Your document "${documentName}" is currently "${documentStatus}".`;

    if (documentStatus === 'Processing') {
        responseMessage += ' We will notify you once it is ready for pick-up. Thank you!';
    } else if (documentStatus === 'Ready for Pick Up') {
        responseMessage += ' You may now pick it up at the branch. Thank you!';
    } else {
        responseMessage = `Good day! Your document "${documentName}" has an unknown status. Please contact support for more information.`;
    }

    var data = {
        notificationId: id,
        contactNumber: contactNumber,
        responseMessage: responseMessage,
    };

    $.ajax({
        url: 'api/send_sms_response.php',
        method: 'POST',
        data: data,
        dataType: 'json',
        success: function (response) {
            console.log('Response:', response);
            showModal(response);

            // Mark notification as read after sending the response
            $.ajax({
                url: 'api/mark_notification_read.php',
                type: 'POST',
                data: { id: id },
                success: function() {
                    // Decrease notification count in the dropdown
                    var notificationCount = $('#notificationCount');
                    var currentCount = parseInt(notificationCount.text(), 10);
                    
                    // Update count only if greater than zero
                    if (currentCount > 0) {
                        notificationCount.text(currentCount - 1);
                    }

                    // Refresh notifications table
                    fetchAndUpdateNotifications(); // Refresh notifications table
                },
                error: function() {
                    console.error('Failed to mark notification as read');
                }
            });
        },
        error: function (xhr, status, error) {
            console.error('Error sending response:', xhr.status, error);
            $('#errorModal #errorMessageText').text(`Error ${xhr.status}: ${xhr.statusText}`);
            $('#errorModal').modal('show');
        }
    });
});


    // Function to show success or error modal
    function showModal(response) {
        if (response.status === 'success') {
            $('#successModal #successMessageText').text(response.message);
            $('#successModal').modal('show');
        } else {
            $('#errorModal #errorMessageText').text(response.message);
            $('#errorModal').modal('show');
        }
    }
});
