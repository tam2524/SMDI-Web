$(document).ready(function() {
    // Function to toggle sidebar
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    // Event listener for sidebar toggle button
    $('#sidebarToggle').on('click', toggleSidebar);
});
$(document).ready(function() {
    // Function to toggle sidebar
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    // Event listener for sidebar toggle button
    $('#sidebarToggle').on('click', toggleSidebar);
    
    // Fetch dashboard data
    fetchDashboardData();
    fetchStatistics();
    fetchTableData();
    fetchActionLogs();
    fetchLoginAttempts(); 
});



function fetchLoginAttempts() {
    $.ajax({
        url: 'api/login_attempts.php', // This file fetches logs from multiple tables
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            var tableBody = $('#loginAttemptsTable tbody');
            tableBody.empty();
            data.forEach(function(attempt) {
                var row = `
                   <tr>
                            <td>${attempt.username}</td>
                            <td>${attempt.attempts}</td>
                            <td>${new Date(attempt.last_attempt).toLocaleString()}</td>
                        </tr>
                `;
                tableBody.append(row);
            });
        },
        error: function() {
            alert('Failed to fetch action logs.');
        }
    });
}
function fetchActionLogs() {
    $.ajax({
        url: 'api/action_logs.php', // This file fetches logs from multiple tables
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            var tableBody = $('#actionLogsTable tbody');
            tableBody.empty();
            data.forEach(function(log) {
                var row = `
                    <tr>
                        <td>${log.id}</td>
                        <td>${log.status}</td>
                        <td>${log.encoded_by}</td>
                        <td>${new Date(log.last_updated).toLocaleString()}</td>
                        <td>${log.table}</td> <!-- Display the source table -->
                    </tr>
                `;
                tableBody.append(row);
            });
        },
        error: function() {
            alert('Failed to fetch action logs.');
        }
    });
}

function fetchDashboardData() {
    $.ajax({
        url: 'api/dashboard_data.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            $('#totalUsers').text(data.totalUsers);
            $('#totalCustomers').text(data.totalCustomers);
            $('#totalDocuments').text(data.totalDocuments);
            
            // Add these lines for document status counts
            $('#processingDocuments').text(data.processingDocuments || 0);
            $('#readyForPickupDocuments').text(data.readyForPickupDocuments || 0);
            $('#releasedDocuments').text(data.releasedDocuments || 0);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching dashboard data:', {
                status: status,
                error: error,
                responseText: xhr.responseText
            });
            alert('Failed to fetch dashboard data.');
        }
    });
}


function getMonthName(monthNumber) {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[monthNumber - 1] || 'Unknown';
}

function fetchStatistics() {
    $.ajax({
        url: 'api/data_statistics.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            var ctxUser = document.getElementById('userChart').getContext('2d');
            var userChart = new Chart(ctxUser, {
                type: 'bar',
                data: {
                    labels: data.months.map(month => getMonthName(parseInt(month))),
                    datasets: [{
                        label: 'Users',
                        data: data.counts,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)', // Light blue
                        borderColor: 'rgba(54, 162, 235, 1)', // Darker blue
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Pie chart for document status
            var ctxDoc = document.getElementById('documentChart').getContext('2d');
            var documentChart = new Chart(ctxDoc, {
                type: 'pie',
                data: {
                    labels: ['On Processing', 'Ready for Pick Up', 'Released'],
                    datasets: [{
                        data: [
                            data.processingDocuments,
                            data.readyForPickupDocuments,
                            data.releasedDocuments
                        ],
                        backgroundColor: [
                            'rgba(173, 216, 230, 0.6)', // Light blue for On Processing
                            'rgba(70, 130, 180, 0.6)', // Steel blue for Ready for Pick Up
                            'rgba(0, 102, 204, 0.6)' // Dark blue for Released
                        ],
                        borderColor: [
                            'rgba(173, 216, 230, 1)', // Light blue
                            'rgba(70, 130, 180, 1)', // Steel blue
                            'rgba(0, 102, 204, 1)' // Dark blue
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Document Status'
                        }
                    }
                }
            });
        },
        error: function() {
            alert('Failed to fetch user statistics.');
        }
    });
}



// Fetch Table Data
function fetchTableData() {
    $.ajax({
        url: 'api/user_list.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            var tableBody = $('#dataTable tbody');
            tableBody.empty();
            data.forEach(function(user) {
                var row = `
                    <tr>
                        <td>${user.username}</td>
                        <td>${user.role}</td>
                        <td>
                            <button class="btn btn-primary text-white view-user" data-id="${user.id}">View</button>
                            <button class="btn btn-primary text-white edit-user" data-id="${user.id}">Edit</button>
                        </td>
                    </tr>
                `;
                tableBody.append(row);
            });
            $('#dataTable').DataTable();
        },
        error: function() {
            alert('Failed to fetch user list.');
        }
    });

    
}
