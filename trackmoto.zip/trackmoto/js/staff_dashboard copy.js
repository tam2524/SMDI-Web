$(document).ready(function() {
    let selectedRecordIds = [];
    let RecordIdToDelete = null;
    let currentPage = 1;
    const recordsPerPage = 15;
    let sortColumn = 'date_reg'; // Default sort column
    let sortOrder = 'ASC'; // Default sort order

    // Load records from the server
    function loadRecords(query = '') {
        $.ajax({
            url: 'api/fetch_records.php',
            method: 'GET',
            data: {
                query: query,
                page: currentPage,
                limit: recordsPerPage,
                sort: sortColumn,
                order: sortOrder
            },
            success: function(data) {
                $('#RecordTableBody').empty(); // Clear table before populating
                if (data.records && data.records.length > 0) {
                    data.records.forEach(record => {
                        $('#RecordTableBody').append(`
                            <tr data-id='${record.record_id}'>
                                <td class='no-print'><input type='checkbox' class='recordCheckbox' value='${record.record_id}'></td>
                                <td>${record.date_reg}</td>
                                <td>${record.family_name}</td>
                                <td>${record.first_name}</td>
                                <td>${record.middle_initial}</td>
                                <td>${record.plate_number}</td>
                                <td>${record.mv_file}</td>
                                <td>${record.branch}</td>
                                <td>${record.batch}</td>
                                <td>${record.remarks}</td>
                                <td class='no-print'>
                                    <button class='btn btn-sm text-white btn-primary edit-button'>Edit</button>
                                </td>
                            </tr>
                        `);
                    });
                } else {
                    $('#RecordTableBody').html("<tr><td colspan='10'>No records found</td></tr>");
                }
                setupPagination(data.total);
            },
            error: function(xhr, status, error) {
                console.error("Error loading records:", error);
            }
        });
    }

    // Load records on initial page load
    loadRecords();

    function setupPagination(totalRecords) {
        const totalPages = Math.ceil(totalRecords / recordsPerPage);
        $('#prevPage').toggleClass('disabled', currentPage === 1);
        $('#nextPage').toggleClass('disabled', currentPage === totalPages);
    
        // Update the page link's state
        $('#prevPage a').attr('aria-disabled', currentPage === 1);
        $('#nextPage a').attr('aria-disabled', currentPage === totalPages);
    }

    $('#prevPage').on('click', function(e) {
        e.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            loadRecords($('#searchInput').val());
        }
    });
    
    $('#nextPage').on('click', function(e) {
        e.preventDefault();
        currentPage++;
        loadRecords($('#searchInput').val());
    });

    // Search functionality
    $('#searchInput').on('input', function() {
        loadRecords($(this).val());
    });

    // Sorting functionality
    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        sortColumn = sortOption === 'familyName' ? 'family_name' : sortColumn; // Update sort column
        sortOrder = sortOrder === 'ASC' ? 'DESC' : 'ASC'; // Toggle sort order
        loadRecords($('#searchInput').val()); // Reload records with new sort parameters
    });

    // Add record functionality
    $('#addRecordForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'api/add_record.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords();
                    $('#addRecordModal').modal('hide');
                    showSuccessModal(response.message);
                    $('#addRecordForm')[0].reset();
                } else {
                    showErrorModal(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error adding record:", error);
            }
        });
    });

    // Edit record functionality
    $('#RecordTableBody').on('click', '.edit-button', function() {
        let recordId = $(this).closest('tr').data('id');
    
        $.ajax({
            url: 'api/get_record.php',
            method: 'GET',
            datatype: 'json',
            data: { id: recordId },
            success: function(response) {
                try {
                    let record = JSON.parse(response);
                    console.log("Fetched Record :", record); // Debugging line
    
                    // Populate the edit form with the fetched record
                    $('#editRecordId').val(record.record_id);
                    $('#editDatereg').val(record.date_reg || '');
                    $('#editFamilyName').val(record.family_name || '');
                    $('#editFirstName').val(record.first_name || '');
                    $('#editMiddleInitial').val(record.middle_initial || '');
                    $('#editPlateNumber').val(record.plate_number || '');
                    $('#editMvFile').val(record.mv_file || '');
                    $('#editBranch').val(record.branch || '');
                    $('#editBatch').val(record.batch || '');
                    $('#editRemarks').val(record.remarks || '');
    
                    $('#editRecordModal').modal('show');
                } catch (error) {
                    console.error("Error parsing record data:", error);
                }
            },
            error: function() {
                alert('Error fetching the record');
            }
        });
    });

    // Edit record form submission
    $('#editRecordForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'api/edit_record.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords();
                    $('#editRecordModal').modal('hide');
                    showSuccessModal(response.message);
                } else {
                    showErrorModal(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error editing Record:", error);
            }
        });
    });

    // Delete record functionality
    $('#RecordTableBody').on('click', '.delete-button', function() {
        let row = $(this).closest('tr');
        RecordIdToDelete = row.data('id');
        $('#confirmationModal').modal('show');
    });

    $('#confirmDeleteBtn').click(function() {
        if (RecordIdToDelete !== null) {
            $.ajax({
                url: 'api/delete_record.php',
                method: 'POST',
                data: { id: RecordIdToDelete },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        loadRecords();
                        showSuccessModal(response.message);
                    } else {
                        showErrorModal(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error deleting Record:", error);
                },
                complete: function() {
                    $('#confirmationModal').modal('hide');
                    RecordIdToDelete = null;
                }
            });
        }
    });

    // Delete selected records functionality
    $('#deleteSelectedButton').on('click', function() {
        if (selectedRecordIds.length > 0) {
            $('#confirmationModal').modal('show');
        } else {
            showWarningModal('No records selected for deletion.');
        }
    });

    $('#confirmDeleteBtn').click(function() {
        if (selectedRecordIds.length > 0) {
            $.ajax({
                url: 'api/delete_record.php',
                method: 'POST',
                data: { ids: selectedRecordIds },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        loadRecords();
                        showSuccessModal(response.message);
                    } else {
                        showErrorModal(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error deleting records:", error);
                },
                complete: function() {
                    $('#confirmationModal').modal('hide');
                    selectedRecordIds = [];
                }
            });
        }
    });

    // Print selected records functionality
    $('#printButton').on('click', function() {
        if (selectedRecordIds.length > 0) {
            printSelectedRecords();
        } else {
            showWarningModal('No records selected for printing.');
        }
    });

    function updateSelectedRecords() {
        selectedRecordIds = [];
        $('#RecordTableBody .recordCheckbox:checked').each(function() {
            selectedRecordIds.push($(this).closest('tr').data('id'));
        });
    }

    function printSelectedRecords() {
        const printContent = $('<div></div>');
        const header = $('<div style="text-align: center; margin-bottom: 20px;">' +
            '<img src="img/smdi_logo.png" alt="SMDI_Logo" class="logo-tmdc mb-2" style="max-width: 150px;"/>' +
            '<h4 style="font-size: 16px; margin-bottom: 0;">Solid Motorcycle Distributors, Inc.</h4>' +
            '<p style="font-size: 12px; margin-bottom: 0;">1031 Victoria Bldg., Roxas Avenue, Roxas City, Capiz Philippines 5800</p>' +
            '<h2>Masterlists</h2>' +
        '</div>');
        printContent.append(header);

        const table = $('<table class="table table-striped"></table>');
        const thead = $('<thead><tr><th>Date Registered</th><th>Family Name</th><th>First Name</th><th>Middle Initial</th><th>Plate Number</th><th>MV File</th><th>Branch</th><th>Batch</th><th>Remarks</th></tr></thead>');
        const tbody = $('<tbody></tbody>');

        $('#RecordTableBody .recordCheckbox:checked').each(function() {
            const recordCells = $(this).closest('tr').find('td:not(.no-print)').map(function() {
                return `<td>${$(this).text()}</td>`;
            }).get().join('');
            tbody.append(`<tr>${recordCells}</tr>`);
        });

        table.append(thead).append(tbody);
        printContent.append(table);

        printJS({
            printable: printContent.html(),
            type: 'raw-html',
            style: `/* Add your custom styles here */`
        });
    }

    // Select All Checkbox Functionality
    $('#selectAllCheckbox').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('#RecordTableBody .recordCheckbox').prop('checked', isChecked);
        updateSelectedRecords();
    });

    $('#RecordTableBody').on('change', '.recordCheckbox', function() {
        updateSelectedRecords();
    });

    // Show success modal function
    function showSuccessModal(message) {
        $('#successModal .modal-body').text(message);
        $('#successModal').modal('show');
    }

    // Show error modal function
    function showErrorModal(message) {
        $('#errorModal .modal-body').text(message);
        $('#errorModal').modal('show');
    }

    // Show warning modal function
    function showWarningModal(message) {
        $('#warningModal .modal-body').text(message);
        $('#warningModal').modal('show');
    }
});
