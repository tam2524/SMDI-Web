$(document).ready(function() {
    let selectedRecordIds = [];
    let RecordIdToDelete = null;
    let currentPage = 1;
    const recordsPerPage = 15;
    let sortColumn = 'date_reg'; // Default sort column
    let sortOrder = 'ASC'; // Default sort order

    // Load records from the server
function loadRecords(query = '') {
    $.ajax({
        url: 'api/fetch_records.php',
        method: 'GET',
        data: {
            query: query,
            page: currentPage,
            limit: recordsPerPage,
            sort: sortColumn,
            order: sortOrder
        },
        success: function(data) {
            $('#RecordTableBody').empty(); // Clear table before populating
            if (data.records && data.records.length > 0) {
                data.records.forEach(record => {
                    $('#RecordTableBody').append(`
                        <tr data-id='${record.record_id}'>
                            <td class='no-print'><input type='checkbox' class='recordCheckbox' value='${record.record_id}'></td>
                            <td>${record.date_reg}</td>
                            <td>${record.family_name}</td>
                            <td>${record.first_name}</td>
                            <td>${record.middle_initial}</td>
                            <td>${record.plate_number}</td>
                            <td>${record.mv_file}</td>
                            <td>${record.branch}</td>
                            <td>${record.batch}</td>
                            <td>${record.remarks}</td>
                            <td class='no-print'>
                                <button class='btn btn-sm text-white btn-primary edit-button'>Edit</button>
                            </td>
                        </tr>
                    `);
                });
        
                // Add the change event handler for checkboxes
                $('#RecordTableBody input.recordCheckbox').on('change', function() {
                    updateSelectedRecords();
                });
            } else {
                $('#RecordTableBody').html("<tr><td colspan='10'>No records found</td></tr>");
            }
            setupPagination(data.total);
        },
        
        error: function(xhr, status, error) {
            console.error("Error loading records:", error);
        }
    });
}

$('#selectAll').on('change', function() {
    const isChecked = $(this).is(':checked');
    $('#RecordTableBody input.recordCheckbox').prop('checked', isChecked);
    updateSelectedRecords();
});


// Load records on initial page load
loadRecords();

function setupPagination(totalRecords) {
    const totalPages = Math.ceil(totalRecords / recordsPerPage);
    $('#prevPage').toggleClass('disabled', currentPage === 1);
    $('#nextPage').toggleClass('disabled', currentPage === totalPages);

    // Update the page link's state
    $('#prevPage a').attr('aria-disabled', currentPage === 1);
    $('#nextPage a').attr('aria-disabled', currentPage === totalPages);
}

$('#prevPage').on('click', function(e) {
    e.preventDefault();
    if (currentPage > 1) {
        currentPage--;
        loadRecords($('#searchInput').val());
    }
});

$('#nextPage').on('click', function(e) {
    e.preventDefault();
    currentPage++;
    loadRecords($('#searchInput').val());
});

// Search functionality
$('#searchInput').on('input', function() {
    loadRecords($(this).val());
});

// Sorting functionality
$('.dropdown-item').on('click', function(e) {
    e.preventDefault();
    const sortOption = $(this).data('sort');
    sortColumn = sortOption === 'familyName' ? 'family_name' : sortColumn; // Update sort column
    sortOrder = sortOrder === 'ASC' ? 'DESC' : 'ASC'; // Toggle sort order
    loadRecords($('#searchInput').val()); // Reload records with new sort parameters
});


// Add record functionality
$('#addRecordForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'api/add_record.php',
        method: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                loadRecords(); // Function to refresh records
                $('#addRecordModal').modal('hide'); // Close the modal
                showSuccessModal(response.message); // Show success modal
                $('#addRecordForm')[0].reset(); // Reset the form
            } else {
                showErrorModal(response.message); // Show error modal
            }
        },
        error: function(xhr, status, error) {
            console.error("Error adding record:", error);
            showErrorModal("An unexpected error occurred. Please try again."); // Optional: show a general error message
        }
    });
});

// Edit record functionality
$('#RecordTableBody').on('click', '.edit-button', function() {
    let recordId = $(this).closest('tr').data('id');

    $.ajax({
        url: 'api/get_record.php',
        method: 'GET',
        datatype: 'json',
        data: { id: recordId },
        success: function(response) {
            try {
                let record = JSON.parse(response);
                console.log("Fetched Record :", record); // Debugging line

                // Populate the edit form with the fetched record
                $('#editRecordId').val(record.record_id);
                $('#editDatereg').val(record.date_reg || ''); // Ensure this is populated
                $('#editFamilyName').val(record.family_name || '');
                $('#editFirstName').val(record.first_name || '');
                $('#editMiddleInitial').val(record.middle_initial || ''); // Ensure this is populated
                $('#editPlateNumber').val(record.plate_number || '');
                $('#editMvFile').val(record.mv_file || '');
                $('#editBranch').val(record.branch || '');
                $('#editBatch').val(record.batch || '');
                $('#editRemarks').val(record.remarks || '');

                $('#editRecordModal').modal('show');
            } catch (error) {
                console.error("Error parsing record data:", error);
            }
        },
        error: function() {
            alert('Error fetching the record');
        }
    });
});

// Edit record form submission
$('#editRecordForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'api/edit_record.php',
        method: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                loadRecords();
                $('#editRecordModal').modal('hide');
                showSuccessModal(response.message);
            } else {
                showErrorModal(response.message);
            }
        },
        error: function(xhr, status, error) {
            console.error("Error editing Record:", error);
        }
    });
});

// Delete record functionality
$('#RecordTableBody').on('click', '.delete-button', function() {
    let row = $(this).closest('tr');
    RecordIdToDelete = row.data('id');
    $('#confirmationModal').modal('show');
});

$('#confirmDeleteBtn').click(function() {
    if (RecordIdToDelete !== null) {
        $.ajax({
            url: 'api/delete_record.php',
            method: 'POST',
            data: { id: RecordIdToDelete },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords();
                    showSuccessModal(response.message);
                } else {
                    showErrorModal(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error deleting Record:", error);
            },
            complete: function() {
                $('#confirmationModal').modal('hide');
                RecordIdToDelete = null;
            }
        });
    }
});


$('#printButton').on('click', function() {
    if (selectedRecordIds.length > 0) {
        printSelectedRecords();
    } else {
        showWarningModal('No records selected for printing.');
    }
});


function printSelectedRecords() {
    if (selectedRecordIds.length > 0) {
        // Iterate through selectedRecordIds to get the corresponding rows
        const selectedRows = selectedRecordIds.map(id => 
            $(`#RecordTableBody tr[data-id="${id}"]`)
        );
        
        const printContent = $('<div></div>');
        const header = $('<div style="text-align: center; margin-bottom: 20px;">' +
            '<img src="img/smdi_logo.png" alt="SMDI_Logo" class="logo-tmdc mb-2" style="max-width: 150px;"/>' +
            '<h4 style="font-size: 16px; margin-bottom: 0;">Solid Motorcycle Distributors, Inc. </h4>' +
            '<p style="font-size: 12px; margin-bottom: 0;">1031 Victoria Bldg., Roxas Avenue, Roxas City, Capiz Philippines 5800</p>' +
            '<h2>Masterlists</h2>' +
        '</div>');
        const table = $('<table class="table table-striped"></table>');
        const thead = $('<thead><tr><th> Date Registered</th><th>Family Name</th><th>First Name</th><th>Middle Initial</th><th>Plate Number</th><th>MV File</th><th>Branch</th><th>Batch</th><th>Remarks</th></tr></thead>');
        const tbody = $('<tbody></tbody>');

        if (selectedRows.length > 0) {
            printContent.append(header);
            table.append(thead);

            selectedRows.forEach(row => {
                const recordCells = row.find('td:not(.no-print)').map(function() {
                    return `<td>${$(this).text()}</td>`;
                }).get().join('');
                tbody.append(`<tr>${recordCells}</tr>`);
            });

            table.append(tbody);
            printContent.append(table);

            printJS({
                printable: printContent.html(),
                type: 'raw-html',
                style: `  h2 {
                    text-align: center;
                    margin-bottom: 20px;
                    font-size: 24px;
                    font-weight: bold;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                }
                th, td {
                    border: 1px solid #ccc;
                    padding: 10px;
                    text-align: left;
                }
                th {
                    font-size: 10px;
                    background-color: #f5f5f5;
                    font-weight: bold;
                    color: #333;
                    text-align: center;
                }
                td {
                    font-size: 14px; /* Adjust font size for readability */
                    border-bottom: 1px solid #e0e0e0;
                }
                .modal-footer, .modal-header {
                    display: none;
                }
                @media print {
                    body {
                        margin: 0;
                        padding: 0;
                        font-family: Arial, sans-serif; /* Use a professional font */
                    }
                    .no-print {
                        display: none !important;
                    }
                    .modal-body {
                        padding: 0;
                        margin: 0;
                    }
                    .modal-content {
                        border: none;
                        box-shadow: none;
                    }
                    table {
                        margin: 0;
                        border: 1px solid #ddd; /* Add border around the table for clarity */
                    }
                }
                @page {
                    margin: 1cm;
                }`
            });
        } else {
            showWarningModal('No records selected for printing.');
        }
    } else {
        showWarningModal('No records selected for printing.');
    }
}


// Print label functionality
$('#RecordTableBody').on('click', '.printLabel-button', function() {
    const row = $(this).closest('tr');
    const familyName = row.find('td:eq(2)').text(); 
    const firstName = row.find('td:eq(3)').text(); 
    const middleInitial = row.find('td:eq(4)').text(); 
    const branch = row.find('td:eq(7)').text(); 

    printLabel(familyName, firstName, middleInitial, branch);
});

function printLabel(familyName, firstName, middleInitial, branch) {
    const printContent = `
        <div style="
            font-size: 20px;
            text-align: left;
            padding: 20px;
            border: 1px solid #000;
            border-radius: 5px;
            display: inline-block;
            width: 80%;
            margin: auto;
        ">
            <p style="margin: 5px 0;">
                <span style="font-weight: bold;">${familyName}, ${firstName} ${middleInitial}</span>
                  <span style="color: red; font-weight: normal;">Branch:</span> 
                <span style="font-weight: bold;">${branch}</span>
            </p>
        </div>
    `;

    printJS({
        printable: printContent,
        type: 'raw-html',
        style: `
            div {
                font-size: 12px;
                text-align: center;
                padding: 20px;
                display: inline-block;
                width: 80%;
                margin: auto;
            }
            p {
                margin: 5px 0;
            }
            span {
                font-weight: normal;
            }
            @media print {
                body {
                    margin: 0;
                    padding: 0;
                }
            }
        `
    });
}

// Print selected labels functionality
$('#printLabelsButton').on('click', function() {
    if (selectedRecordIds.length > 0) {
        printSelectedLabels();
    } else {
        showWarningModal('No records selected for printing labels.');
    }
});

function printSelectedLabels() {
    const printContent = $('<div></div>');
    const selectedRows = $('#RecordTableBody input.recordCheckbox:checked').closest('tr');

    selectedRows.each(function() {
        const familyName = $(this).find('td:eq(2)').text();
        const firstName = $(this).find('td:eq(3)').text();
        const middleInitial = $(this).find('td:eq(4)').text();
        const branch = $(this).find('td:eq(7)').text();

        const label = `
            <div style="
                font-size: 20px;
                text-align: left;
                padding: 20px;
                border: 1px solid #000;
                border-radius: 5px;
                display: inline-block;
                width: 80%;
                margin: auto;
                margin-bottom: 20px;
            ">
                <p style="margin: 5px 0;">
                    <span style="font-weight: bold;">${familyName}, ${firstName}, ${middleInitial}</span>
                    <span style="color: red; font-weight: normal;">Branch:</span> 
                    <span style="font-weight: bold;">${branch}</span>
                </p>
            </div>
        `;

        printContent.append(label);
    });

    printJS({
        printable: printContent.html(),
        type: 'raw-html',
        style: `
            div {
                font-size: 12px;
                text-align: center;
                padding: 20px;
                display: inline-block;
                width: 80%;
                margin: auto;
            }
            p {
                margin: 5px 0;
            }
            span {
                font-weight: normal;
            }
            @media print {
                body {
                    margin: 0;
                    padding: 0;
                }
            }
        `
    });
}

function updateSelectedRecords() {
    selectedRecordIds = $('#RecordTableBody input.recordCheckbox:checked').map(function() {
        return $(this).val();
    }).get();
    console.log('Selected Records:', selectedRecordIds); // Debugging line
}


// Delete selected records functionality
$('#deleteSelectedButton').on('click', function() {
    if (selectedRecordIds.length > 0) {
        $('#confirmationModal').modal('show');
    } else {
        showWarningModal('No records selected for deletion.');
    }
});

$('#confirmDeleteBtn').click(function() {
    if (selectedRecordIds.length > 0) {
        $.ajax({
            url: 'api/delete_record.php',
            method: 'POST',
            data: { ids: selectedRecordIds }, // Send the array of IDs
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords(); // Reload records after deletion
                    showSuccessModal(response.message);
                } else {
                    showErrorModal(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error deleting records:", error);
            },
            complete: function() {
                $('#confirmationModal').modal('hide');
                selectedRecordIds = []; // Clear the array after operation
            }
        });
    }
});


// Success modal functionality
function showSuccessModal(message) {
    $('#successMessage').text(message);
    $('#successModal').modal('show');
}

// Error modal functionality
function showErrorModal(message) {
    $('#errorMessage').text(message);
    $('#errorMessage').show();
    setTimeout(() => {
        $('#errorMessage').hide();
    }, 3000);
}

// Warning modal functionality
function showWarningModal(message) {
    $('#warningMessage').text(message);
    $('#warningModal').modal('show');
}

});

document.addEventListener('DOMContentLoaded', function () {
    // Get all necessary elements
    const nextStep1Button = document.getElementById('nextStep1');
    const nextStep2Button = document.getElementById('nextStep2');
    const prevStep2Button = document.getElementById('prevStep2');
    const prevStep3Button = document.getElementById('prevStep3');
    const addRecordForm = document.getElementById('addRecordForm');

    // Step elements
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');

    // Function to show a specific step
    function showStep(step) {
        step1.classList.add('d-none');
        step2.classList.add('d-none');
        step3.classList.add('d-none');

        step.classList.remove('d-none');
    }

    // Event listeners for buttons
    nextStep1Button.addEventListener('click', function () {
        // Show step 2
        showStep(step2);
    });

    nextStep2Button.addEventListener('click', function () {
        // Update confirmation details
        document.getElementById('confirmDateReg').textContent = document.getElementById('datereg').value;
        document.getElementById('confirmFamilyName').textContent = document.getElementById('familyName').value;
        document.getElementById('confirmFirstName').textContent = document.getElementById('firstName').value;
        document.getElementById('confirmMiddleInitial').textContent = document.getElementById('middleInitial').value;
        document.getElementById('confirmPlateNumber').textContent = document.getElementById('plateNumber').value;
        document.getElementById('confirmMVFile').textContent = document.getElementById('mvFile').value;
        document.getElementById('confirmBranch').textContent = document.getElementById('branch').value;
        document.getElementById('confirmBatch').textContent = document.getElementById('batch').value;
        document.getElementById('confirmRemarks').textContent = document.getElementById('remarks').value;
        document.getElementById('confirmEngineNo').textContent = document.getElementById('engineNo').value;
        document.getElementById('confirmChassisNo').textContent = document.getElementById('chassisNo').value;
        document.getElementById('confirmMake').textContent = document.getElementById('make').value;
        document.getElementById('confirmYearModel').textContent = document.getElementById('yearModel').value;
        document.getElementById('confirmSeries').textContent = document.getElementById('series').value;
        document.getElementById('confirmBodyType').textContent = document.getElementById('bodyType').value;
        document.getElementById('confirmDenomination').textContent = document.getElementById('denomination').value;
        document.getElementById('confirmDatePurchase').textContent = document.getElementById('datePurchase').value;

        // Show step 3
        showStep(step3);
    });

    prevStep2Button.addEventListener('click', function () {
        // Show step 1
        showStep(step1);
    });

    prevStep3Button.addEventListener('click', function () {
        // Show step 2
        showStep(step2);
    });

    // Reset form and show step 1 when the modal is opened
    $('#addRecordModal').on('show.bs.modal', function () {
        addRecordForm.reset(); // Reset the form
        $(addRecordForm).find('.form-control').removeClass('is-invalid');
        showStep(step1);
    });
    
    // Function to toggle sidebar
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    // Event listener for sidebar toggle button
    $('#sidebarToggle').on('click', toggleSidebar);
});
    

 // Notification functionality
function fetchAndUpdateDropdownNotifications() {
    $.ajax({
        url: 'api/fetch_notifications.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            const notificationsList = $('#notificationsList');
            const notificationCount = $('#notificationCount');

            notificationsList.empty(); // Clear previous notifications
            let unreadCount = data.unreadCount || 0; // Use the count from the server

            if (data.data.length > 0) {
                data.data.forEach(function(notification) {
                    notificationsList.append(
                        `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                        `${notification.customer_name}: ${notification.message}` +
                        '</a></li>'
                    );
                });
            } else {
                notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
            }
            notificationCount.text(unreadCount); // Update the count
        },
        error: function() {
            $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
            $('#notificationCount').text('0');
        }
    });
}
// Initial fetch and set up polling for notifications
fetchAndUpdateDropdownNotifications();
setInterval(fetchAndUpdateDropdownNotifications, 1000);

$(document).on('click', '.notificationDropdown-item', function () {
    const row = $(this);
    const id = row.data('id');

    // Mark notification as read
    $.ajax({
        url: 'api/mark_notification_read.php',
        method: 'POST',
        data: { id: id },
        success: function () {
            row.removeClass('unread'); // Update UI to show it's read
            fetchAndUpdateDropdownNotifications(); // Refresh notification count

            // Redirect to the notification details page
            window.location.href = 'staff_notifications.php?id=' + id;
        },
        error: function () {
            console.error('Failed to mark notification as read');
        }
    });
});



