$(document).ready(function() {
    // Function to toggle sidebar
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    // Event listener for sidebar toggle button
    $('#sidebarToggle').on('click', toggleSidebar);
});

$(document).ready(function () { 
    let selectedRecordIds = [];
    let searchFilter = '';
    let documentTypeFilter = 'both';
    let statusFilter = 'all';
    let currentPage = 1;
    let totalPages = 1;
    let sortBy = 'date_reg';
    let sortOrder = 'ASC'; // Default sorting order

    // Function to load documents
    function loadDocuments() {
        $.ajax({
            url: 'api/fetch_documents.php',
            method: 'GET',
            data: {
                search: searchFilter,
                type: documentTypeFilter,
                status: statusFilter,
                sort: sortBy,
                order: sortOrder,
                page: currentPage,
                limit: 15
            },
            dataType: 'json',
            success: function (response) {
                if (response.error) {
                    console.error(response.error);
                    $('#DocumentTableBody').html('<tr><td colspan="7">Error loading documents.</td></tr>');
                } else {
                    $('#DocumentTableBody').html(response.html);
                    totalPages = response.totalPages; // Update total pages
                    updatePaginationControls(); // Update pagination controls
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", status, error);
                $('#DocumentTableBody').html('<tr><td colspan="7">Failed to load documents. Please try again later.</td></tr>');
            }
        });
    }
    
    
    
    function updatePaginationControls() {
        $('#DocumentsPaginationControls').find('.page-item').removeClass('disabled');
        
        if (currentPage === 1) {
            $('#prevPage').addClass('disabled');
        }
        if (currentPage === totalPages) {
            $('#nextPage').addClass('disabled');
        }
    }
    
    // Handle Previous Page
    $('#prevPage').on('click', function (e) {
        e.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            loadDocuments();
        }
    });
    
    // Handle Next Page
    $('#nextPage').on('click', function (e) {
        e.preventDefault();
        if (currentPage < totalPages) {
            currentPage++;
            loadDocuments();
        }
    });
    
    // Initial load
    loadDocuments();
   // Handle status dropdown change in the table
$('#DocumentTableBody').on('change', '.status-dropdown', function () {
    const documentId = $(this).closest('tr').data('id');
    const newStatus = $(this).val();

    $.ajax({
        url: 'api/update_document_status.php',
        method: 'POST',
        data: {
            documentId: documentId,
            status: newStatus
        },
        dataType: 'json',
        success: function (response) {
            if (response.status === 'success') {
                showSuccessModal('Status updated successfully.');

                // Move the updated row to the top
                const updatedRow = $(this).closest('tr').detach();
                $('#DocumentTableBody').prepend(updatedRow);
            } else {
                showErrorModal(response.message);
            }
        }.bind(this), // Ensure `this` refers to the dropdown element
        error: function (xhr, status, error) {
            handleAjaxError(xhr, status, error, 'Failed to update status. Please try again.');
        }
    });
});


    // Search functionality with debounce
    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Call loadDocuments on search input change
    $('#searchInput').on('input', debounce(function () {
        searchFilter = $(this).val();
        loadDocuments();
    }, 300));

    $('#printButton').on('click', function () {
        if (selectedRecordIds.length > 0) {
            printSelectedRecords();
        } else {
            showWarningModal('No records selected for printing.');
        }
    });

    function printSelectedRecords() {
        const printContent = $('<div></div>');
        const header = $('<div style="text-align: center; margin-bottom: 20px;">' +
            '<img src="img/smdi_logo.png" alt="SMDI_Logo" class="logo-tmdc mb-2" style="max-width: 150px;"/>' +
            '<h4 style="font-size: 16px; margin-bottom: 0;">Solid Motorcycle Distributors, Inc.</h4>' +
            '<p style="font-size: 12px; margin-bottom: 0;">1031 Victoria Bldg., Roxas Avenue, Roxas City, Capiz Philippines 5800</p>' +
            '<h2>Customer Lists </h2>' +
            '</div>');
        const table = $('<table class="table table-striped"></table>');
        const thead = $('<thead><tr><th>Family Name</th><th>First Name</th><th>Middle Initial</th><th>Branch</th></tr></thead>');
        const tbody = $('<tbody></tbody>');

        const selectedRows = $('#DocumentTableBody input.documentCheckbox:checked').closest('tr');

        if (selectedRows.length > 0) {
            printContent.append(header);
            table.append(thead);

            selectedRows.each(function () {
                const recordCells = $(this).find('td:not(.no-print)').map(function () {
                    return `<td>${$(this).text()}</td>`;
                }).get().join('');

                tbody.append(`<tr>${recordCells}</tr>`);
            });

            table.append(tbody);
            printContent.append(table);

            printJS({
                printable: printContent.html(),
                type: 'raw-html',
                style: `/* styles as in your current code */`
            });
        } else {
            showWarningModal('No records selected for printing.');
        }
    }


    // Modal functions
    function showSuccessModal(message) {
        $('#successMessage').text(message);
        $('#successModal').modal('show');
    }

    function showErrorModal(message) {
        $('#errorMessage').text(message);
        $('#errorMessage').show();
        setTimeout(() => $('#errorMessage').hide(), 3000);
    }

    function showWarningModal(message) {
        $('#warningMessage').text(message);
        $('#warningModal').modal('show');
    }
   
    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        
        console.log(`Sorting by: ${sortOption}`);
        
        switch (sortOption) {
            case 'familyName':
                sortBy = 'customer_name'; // Adjust sortBy to the correct column
                sortOrder = 'ASC'; // Sort ascending
                break;
            case 'dateReg':
                sortBy = 'date_reg'; // Adjust sortBy to the correct column
                sortOrder = 'ASC'; // Sort ascending
                break;
            case 'lastUpdated':
                sortBy = 'last_updated'; // Adjust sortBy to the correct column
                sortOrder = 'DESC'; // Sort latest first
                break;
            default:
                return; // Exit if no valid sort option is found
        }

        loadDocuments(); // Reload documents with new sorting
    });
    
    

    // Handle report generation form submission
    $('#reportForm').on('submit', function(e) {
        e.preventDefault();
        const formData = $(this).serialize();

        $.ajax({
            type: 'POST',
            url: 'api/generate_report.php',
            data: formData,
            success: function(response) {
                // Handle success - you can either download the report or show a message
                window.location.href = 'api/generate_report.php?' + formData;
            },
            error: function(xhr, status, error) {
                console.error('Failed to generate report:', status, error);
                showErrorModal('Failed to generate report. Please try again.');
            }
        });
    });

    $(document).on('click', '.notifyButton', function () {
        console.log("Notify Me button clicked"); // Debug log
        var docId = $(this).data('id'); // Get the document ID
        $('#notifyCustomerModal').data('documentId', docId); // Store document ID
        
        var myModal = new bootstrap.Modal(document.getElementById('notifyCustomerModal'));
        myModal.show();
    });
    
    
    // Handle notification form submission
    $('#notificationForm').on('submit', function(e) {
        e.preventDefault();
        const contactNumber = $('#contactNumber').val();
        const documentId = $('#notifyCustomerModal').data('documentId'); // Get the stored document ID
    
        // Fetch document status
        $.ajax({
            url: 'api/fetch_document_status.php', // Update this to your actual endpoint
            method: 'GET',
            data: { document_id: documentId },
            dataType: 'json',
            success: function(statusResponse) {
                if (statusResponse.status === 'success') {
                    // Assuming the document type and status are in statusResponse.data
                    const document = statusResponse.data[0]; // Adjust if needed based on response structure
                    const documentStatus = document.status; // Adjust based on your actual response
                    const documentType = document.document_type || 'Your Document'; // Use document_type instead
    
                    let responseMessage = `Good day! The status of your document (${documentType}) is ${documentStatus}.`;
    
                    // Add additional message based on document status
                    if (documentStatus === 'On Processing') {
                        responseMessage += ' We will notify you once it is ready for pick-up. Thank you!';
                    } else if (documentStatus === 'Ready for Pick Up') {
                        responseMessage += ' You may now pick it up at the branch. Thank you!';
                    } else {
                        responseMessage = `Good day! Your document type "${documentType}" has an unknown status. Please contact support for more information.`;
                    }
    
                    // Now send the SMS
                    sendSMS(contactNumber, responseMessage);
                } else {
                    showErrorModal('Failed to fetch document status.');
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                showErrorModal('Failed to fetch document status. Please try again.');
            }
        });
    });
    
    
    // Function to send SMS
    function sendSMS(contactNumber, message) {
        $.ajax({
            url: 'api/notify_customer.php',
            method: 'POST',
            data: {
                contactNumber: contactNumber, // Make sure the key matches what is expected in PHP
                responseMessage: message // Use the correct key
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    showSuccessModal('Notification sent successfully.');
                    $('#notifyCustomerModal').modal('hide'); // Close the modal
                } else {
                    showErrorModal(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                showErrorModal('Failed to send notification. Please try again.');
            }
        });
    }
    
    



    // Notification functionality
 function fetchAndUpdateDropdownNotifications() {
    $.ajax({
        url: 'api/fetch_notifications.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var notificationsList = $('#notificationsList');
            var notificationCount = $('#notificationCount');
            
            notificationsList.empty(); // Clear the previous notifications
            if (data.length > 0) {
                data.forEach(function(notification) {
                    notificationsList.append(
                        `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                        `${notification.customer_name}: ${notification.message}` +
                        '</a></li>'
                    );
                });
                notificationCount.text(data.length);
            } else {
                notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
                notificationCount.text('0');
            }
        },
        error: function() {
            $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
            $('#notificationCount').text('0');
        }
    });
}

// Initial fetch and set up polling for dropdown notifications
fetchAndUpdateDropdownNotifications();
setInterval(fetchAndUpdateDropdownNotifications, 5000); // Poll every 5 seconds

$(document).on('click', '.notificationDropdown-item', function(e) { // Changed selector here
    e.preventDefault();
    var notificationId = $(this).data('id');

    // AJAX request to mark notification as read
    $.ajax({
        url: 'api/mark_notification_read.php', // Endpoint to mark as read
        type: 'POST',
        data: { id: notificationId },
        success: function() {
            // Update the UI after marking as read
            var notificationCount = $('#notificationCount');
            var currentCount = parseInt(notificationCount.text());
            
            // Decrease the notification count
            if (currentCount > 0) {
                notificationCount.text(currentCount - 1);
            }
            // Optionally remove or update the notification in the list
            $(`a[data-id="${notificationId}"]`).parent().remove();
        },
        error: function() {
            console.error('Failed to mark notification as read');
        }
    });

    // Redirect to staff_notifications.php with the notification ID in the URL
    window.location.href = 'staff_notifications.php?id=' + notificationId;
});

});




