$(document).ready(function() {

    $(document).ready(function() {
        // Function to toggle sidebar
        function toggleSidebar() {
            $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
            $('.smdi-main-content').toggleClass('smdi-main-content--full');
        }
    
        // Event listener for sidebar toggle button
        $('#sidebarToggle').on('click', toggleSidebar);
    });

});

$(document).ready(function() {
    $('#time_frame').change(function() {
        if ($(this).val() === 'custom') {
            $('#custom_dates').show();
        } else {
            $('#custom_dates').hide();
        }
    });
});
    

function toggleDateInputs() {
    const timeFrame = document.querySelector('select[name="time_frame"]').value;
    const dateInputs = document.getElementById('custom-dates');
    if (timeFrame === 'custom') {
        dateInputs.style.display = 'block';
        document.getElementById('start_date').setAttribute('required', 'required');
        document.getElementById('end_date').setAttribute('required', 'required');
    } else {
        dateInputs.style.display = 'none';
        document.getElementById('start_date').removeAttribute('required');
        document.getElementById('end_date').removeAttribute('required');
    }
}

   
function fetchAndUpdateDropdownNotifications() {
    $.ajax({
        url: 'api/fetch_notifications.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            const notificationsList = $('#notificationsList');
            const notificationCount = $('#notificationCount');

            notificationsList.empty(); // Clear previous notifications
            let unreadCount = data.unreadCount || 0; // Use the count from the server

            if (data.data.length > 0) {
                data.data.forEach(function(notification) {
                    notificationsList.append(
                        `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                        `${notification.customer_name}: ${notification.message}` +
                        '</a></li>'
                    );
                });
            } else {
                notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
            }
            notificationCount.text(unreadCount); // Update the count
        },
        error: function() {
            $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
            $('#notificationCount').text('0');
        }
    });
}
// Initial fetch and set up polling for notifications
fetchAndUpdateDropdownNotifications();
setInterval(fetchAndUpdateDropdownNotifications, 1000);

$(document).on('click', '.notificationDropdown-item', function () {
    const row = $(this);
    const id = row.data('id');

    // Mark notification as read
    $.ajax({
        url: 'api/mark_notification_read.php',
        method: 'POST',
        data: { id: id },
        success: function () {
            row.removeClass('unread'); // Update UI to show it's read
            fetchAndUpdateDropdownNotifications(); // Refresh notification count

            // Redirect to the notification details page
            window.location.href = 'staff_notifications.php?id=' + id;
        },
        error: function () {
            console.error('Failed to mark notification as read');
        }
    });
});
