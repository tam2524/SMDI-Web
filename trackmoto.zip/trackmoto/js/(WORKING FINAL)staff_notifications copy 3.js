$(document).ready(function () {

    //hakdog
    function fetchAndUpdateNotifications() {
        $.ajax({
            url: 'api/get_follow_up_notifications.php',
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                let html = '';
                if (response.status === 'success') {
                    response.data.forEach(function (notification) {
                        html += `<tr class="email-item${notification.status === 'unread' ? ' unread' : ''}" data-id="${notification.id}">` +
                            `<td>${notification.id}</td>` +
                            `<td>${notification.customer_name}</td>` +
                            `<td>${notification.contact_number}</td>` +
                            `<td>${notification.message}</td>` +
                            `<td>${notification.document_name || 'Not Available'}</td>` +
                            `<td>${notification.document_status || 'Not Available'}</td>` +
                            `<td><button class="btn btn-primary text-white respond-btn">Respond</button></td>` +
                            `</tr>`;
                    });
                } else {
                    html = `<tr><td colspan="7">${response.message}</td></tr>`; // Adjusted colspan to match the number of columns
                }
                $('#notificationsTable').html(html);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching notifications:', xhr.status, error);
                $('#errorModal #errorMessageText').text('An error occurred while fetching notifications.');
                $('#errorModal').modal('show');
            }
        });
    }    

    function fetchAndUpdateDropdownNotifications() {
        $.ajax({
            url: 'api/fetch_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                const notificationsList = $('#notificationsList');
                const notificationCount = $('#notificationCount');
    
                notificationsList.empty(); // Clear previous notifications
                let unreadCount = data.unreadCount || 0; // Use the count from the server
    
                if (data.data.length > 0) {
                    data.data.forEach(function(notification) {
                        notificationsList.append(
                            `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                            `${notification.customer_name}: ${notification.message}` +
                            '</a></li>'
                        );
                    });
                } else {
                    notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
                }
                notificationCount.text(unreadCount); // Update the count
            },
            error: function() {
                $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
                $('#notificationCount').text('0');
            }
        });
    }
    
    

    // Initial fetch and set up polling for notifications
    fetchAndUpdateNotifications();
    fetchAndUpdateDropdownNotifications();
    setInterval(fetchAndUpdateDropdownNotifications, 1000);
    setInterval(fetchAndUpdateNotifications, 1000);
     // Poll every 5 seconds

    $(document).on('click', '.email-item', function () {
        const row = $(this);
        const id = row.data('id');

        // Mark notification as read
        $.ajax({
            url: 'api/mark_notification_read.php',
            method: 'POST',
            data: { id: id },
            success: function () {
                row.removeClass('unread'); // Update UI to show it's read
                fetchAndUpdateDropdownNotifications(); // Refresh notification count

                // Redirect to the notification details page
                window.location.href = 'staff_notifications.php?id=' + id;
            },
            error: function () {
                console.error('Failed to mark notification as read');
            }
        });
    });

    // Handle response button clicks
    $(document).on('click', '.respond-btn', function (event) {
        event.stopPropagation();
        const row = $(this).closest('tr');
        const id = row.data('id');
        const contactNumber = row.find('td').eq(2).text();
        const documentStatus = row.find('td').eq(5).text();
        const documentName = row.find('td').eq(4).text();

        let responseMessage = `Good day! The status of your document (${documentName}) is ${documentStatus}.`;

        // Add additional message based on document status
        if (documentStatus === 'Processing') {
            responseMessage += ' We will notify you once it is ready for pick-up. Thank you!';
        } else if (documentStatus === 'Ready for Pick Up') {
            responseMessage += ' You may now pick it up at the branch. Thank you!';
        } else {
            responseMessage = `Good day! Your document "${documentName}" has an unknown status. Please contact support for more information.`;
        }

        const data = {
            notificationId: id,
            contactNumber: contactNumber,
            responseMessage: responseMessage
        };

        $.ajax({
            url: 'api/send_sms_response.php',
            method: 'POST',
            data: data,
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    $('#successModal #successMessageText').text(response.message);
                    $('#successModal').modal('show');

                    // Mark the notification as read
                    $.ajax({
                        url: 'api/mark_notification_read.php',
                        method: 'POST',
                        data: { id: id },
                        success: function () {
                            row.removeClass('unread'); // Update the row to reflect the "read" status
                            fetchAndUpdateDropdownNotifications(); // Refresh notification count
                        },
                        error: function () {
                            console.error('Error marking notification as read');
                        }
                    });
                } else {
                    $('#errorModal #errorMessageText').text(response.message);
                    $('#errorModal').modal('show');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error sending response:', xhr.status, error);
                $('#errorModal #errorMessageText').text('An error occurred while sending the message.');
                $('#errorModal').modal('show');
            }
        });
    });
});
