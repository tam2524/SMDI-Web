$(document).ready(function() {
    $('#searchForm').on('submit', function(event) {
        event.preventDefault();
        var lastName = $('#lastName').val();
        var firstName = $('#firstName').val();

        $.ajax({
            url: 'api/get_document_status.php',
            method: 'POST',
            data: {
                lastName: lastName,
                firstName: firstName
            },
            dataType: 'json',
            success: function(response) {
                var html = '';
                var documents = response.data; 
                if (documents.length === 0) {
                    html = '<p>No documents found.</p>';
                } else {
                    html = '<table class="table table-striped">' +
                           '<thead><tr><th>Date Registered</th><th>Make</th><th>Series</th><th>Document Type</th><th>Document Number</th><th>Status</th><th>Action</th></tr></thead>' +
                           '<tbody>';
                    documents.forEach(function(doc) {
                        html += '<tr>' +
                                '<td>' + (doc.date_reg || 'N/A') + '</td>' +
                                '<td>' + (doc.make || 'N/A') + '</td>' +
                                '<td>' + (doc.series || 'N/A') + '</td>' +
                                '<td>' + (doc.document_type || 'N/A') + '</td>' +
                                '<td>' + (doc.document_number || 'N/A') + '</td>' +
                                '<td>' + (doc.status || 'N/A') + '</td>' +
                                '<td><button class="btn btn-primary text-white followUpBtn" data-document-id="' + doc.document_id + '" data-customer-name="' + doc.customer_name + '">Follow Up</button></td>' +
                                '</tr>';
                    });
                    html += '</tbody></table>';
                }
                $('#statusResults').html(html);

                // Add event listener for follow-up buttons
                $('.followUpBtn').on('click', function() {
                    var documentId = $(this).data('document-id');
                    var customerName = $(this).data('customer-name');
                    $('#documentId').val(documentId);
                    $('#customerName').val(customerName);
                    $('#followUpModal').modal('show');
                });
            },
            error: function() {
                $('#warningModal #warningMessage').text('An error occurred while fetching the document status.');
                $('#warningModal').modal('show');
            }
        });
    });

    // Handle follow-up form submission
    $('#followUpForm').on('submit', function(event) {
        event.preventDefault();
        var documentId = $('#documentId').val();
        var customerName = $('#customerName').val();
        var contactNumber = $('#contactNumber').val();
        var followUpMessage = $('#followUpMessage').val();

        $.ajax({
            url: 'api/submit_follow_up.php',
            method: 'POST',
            data: {
                documentId: documentId,
                customerName: customerName,
                contactNumber: contactNumber,
                followUpMessage: followUpMessage
            },
            success: function(response) {
                $('#successModal #successMessage').text('Follow-up message has been successfully sent.');
                $('#successModal').modal('show');
                $('#followUpModal').modal('hide');
                $('#followUpForm')[0].reset(); // Reset form
            },
            error: function() {
                $('#warningModal #warningMessage').text('An error occurred while saving the follow-up.');
                $('#warningModal').modal('show');
            }
        });
    });
});
