$(document).ready(function() {
    let selectedRecordIds = [];
    let currentPage = 1;
    const recordsPerPage = 15;
    let totalPages = 0;
    let sortColumn = 'family_name'; // Default sort column
    let sortOrder = 'ASC'; // Default sort order

    // Load records function
   function loadRecords(query = '', page = 1) {
        $.ajax({
            url: 'api/fetch_customers.php',
            method: 'GET',
            data: { query: query, page: page, recordsPerPage: recordsPerPage, sort: sortColumn, order: sortOrder },
            success: function(data) {
                const response = JSON.parse(data);
                const customers = response.customers;
                totalPages = response.totalPages; // Set totalPages from the response

                setupPagination();

                $('#CustomerTableBody').empty();
                customers.forEach(customer => {
                    $('#CustomerTableBody').append(
                        `<tr data-id="${customer.customer_id}">
                             <td>${customer.family_name}</td>
                             <td>${customer.first_name}</td>
                             <td>${customer.middle_initial}</td>
                             <td>${customer.branch}</td>
                             <td class='no-print'>
                                 <button class='btn btn-sm text-white btn-primary edit-button' data-id='${customer.customer_id}'>View Motorcycle</button>
                             </td>
                        </tr>`
                    );
                });
            },
            error: function(xhr, status, error) {
                console.error("Error loading records:", error);
            }
        });
    }
    // Sorting functionality
    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        
        switch (sortOption) {
            case 'familyName':
                sortColumn = 'family_name';
                break;
            case 'firstName':
                sortColumn = 'first_name';
                break;
            case 'dateReg':
                sortColumn = 'date_reg';
                break;
            // Add more cases as needed
        }

        sortOrder = (sortOrder === 'ASC') ? 'DESC' : 'ASC';
        loadRecords($('#searchInput').val(), currentPage); // Reload records with sorting
    });

    loadRecords(); // Initial call

    // Edit record functionality
    $('#CustomerTableBody').on('click', '.edit-button', function() {
        const customerId = $(this).closest('tr').data('id');

        $.ajax({
            url: 'api/get_customer.php',
            method: 'GET',
            dataType: 'json',
            data: { customerId: customerId },
            success: function(response) {
                if (response && response.customer) {
                    const customer = response.customer;
                    $('#editCustomerId').val(customer.customer_id);
                    $('#editFamilyName').val(customer.family_name);
                    $('#editFirstName').val(customer.first_name);
                    $('#editMiddleName').val(customer.middle_initial);

                    $.ajax({
                        url: 'api/get_motorcycle.php',
                        method: 'GET',
                        data: { customerId: customerId },
                        dataType: 'json',
                        success: function(motorcycleResponse) {
                            $('#engineNo').val(motorcycleResponse.engine_no || '');
                            $('#chassisNo').val(motorcycleResponse.chassis_no || '');
                            $('#make').val(motorcycleResponse.make || '');
                            $('#yearModel').val(motorcycleResponse.year_model || '');
                            $('#series').val(motorcycleResponse.series || '');
                            $('#bodyType').val(motorcycleResponse.body_type || '');
                            $('#denomination').val(motorcycleResponse.denomination || '');
                            $('#datePurchase').val(motorcycleResponse.date_purchase || '');
                        },
                        error: function() {
                            alert('Error fetching motorcycle details');
                        }
                    });

                    $('#editRecordModal').modal('show');
                } else {
                    console.error('Invalid customer data:', response);
                }
            },
            error: function() {
                alert('Error fetching the record');
            }
        });
    });

    // Submit edited record
    $('#editRecordForm').on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: 'api/edit_customer.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords();
                    $('#editRecordModal').modal('hide');
                    showSuccessModal(response.message);
                } else {
                    $('#duplicateErrorMessage').text(response.message);
                    $('#duplicateErrorModal').modal('show');
                }
            },
            error: function(xhr, status, error) {
                console.error("Error saving record:", error);
            }
        });
    });

    function setupPagination() {
        $('#prevPage').toggleClass('disabled', currentPage === 1);
        $('#nextPage').toggleClass('disabled', currentPage === totalPages);

        // Update the page link's state
        $('#prevPage a').attr('aria-disabled', currentPage === 1);
        $('#nextPage a').attr('aria-disabled', currentPage === totalPages);
    }

    $('#prevPage').on('click', function(e) {
        e.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            console.log("Current Page (Prev):", currentPage); // Debugging statement
            loadRecords($('#searchInput').val(), currentPage);
        }
    });

    $('#nextPage').on('click', function(e) {
        e.preventDefault();
        if (currentPage < totalPages) { // Ensure we don't exceed total pages
            currentPage++;
            console.log("Current Page (Next):", currentPage); // Debugging statement
            loadRecords($('#searchInput').val(), currentPage);
        }
    });
 $('#searchInput').on('input', function() {
        loadRecords($(this).val(), currentPage); // Keep the current page on search
    });

    loadRecords(); 
    
// Notification functionality
function fetchAndUpdateDropdownNotifications() {
    $.ajax({
        url: 'api/fetch_notifications.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            const notificationsList = $('#notificationsList');
            const notificationCount = $('#notificationCount');

            notificationsList.empty(); // Clear previous notifications
            let unreadCount = data.unreadCount || 0; // Use the count from the server

            if (data.data.length > 0) {
                data.data.forEach(function(notification) {
                    notificationsList.append(
                        `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                        `${notification.customer_name}: ${notification.message}` +
                        '</a></li>'
                    );
                });
            } else {
                notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
            }
            notificationCount.text(unreadCount); // Update the count
        },
        error: function() {
            $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
            $('#notificationCount').text('0');
        }
    });
}
// Initial fetch and set up polling for notifications
fetchAndUpdateDropdownNotifications();
setInterval(fetchAndUpdateDropdownNotifications, 1000);

$(document).on('click', '.notificationDropdown-item', function () {
    const row = $(this);
    const id = row.data('id');

    // Mark notification as read
    $.ajax({
        url: 'api/mark_notification_read.php',
        method: 'POST',
        data: { id: id },
        success: function () {
            row.removeClass('unread'); // Update UI to show it's read
            fetchAndUpdateDropdownNotifications(); // Refresh notification count

            // Redirect to the notification details page
            window.location.href = 'staff_notifications.php?id=' + id;
        },
        error: function () {
            console.error('Failed to mark notification as read');
        }
    });
});


// Sidebar toggle function
function toggleSidebar() {
    $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
    $('.smdi-main-content').toggleClass('smdi-main-content--full');
}
$('#sidebarToggle').on('click', toggleSidebar);

});
