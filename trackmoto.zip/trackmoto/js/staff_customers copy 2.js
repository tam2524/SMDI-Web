$(document).ready(function() {
    let selectedRecordIds = [];
    let currentPage = 1;
    const recordsPerPage = 15;
    let totalPages = 0;
    let sortColumn = 'family_name'; // Default sort column
    let sortOrder = 'ASC'; // Default sort order

    // Load records function
    function loadRecords(query = '', page = 1) {
        $.ajax({
            url: 'api/fetch_customers.php',
            method: 'GET',
            data: { query: query, page: page, recordsPerPage: recordsPerPage, sort: sortColumn, order: sortOrder },
            success: function(data) {
                const response = JSON.parse(data);
                const customers = response.customers;
                totalPages = response.totalPages;
                setupPagination();

                $('#CustomerTableBody').empty();
                customers.forEach(customer => {
                    $('#CustomerTableBody').append(
                        `<tr data-id="${customer.customer_id}">
                             <td>${customer.family_name}</td>
                             <td>${customer.first_name}</td>
                             <td>${customer.middle_initial}</td>
                             <td>${customer.branch}</td>
                             <td class='no-print'>
                                 <button class='btn btn-sm text-white btn-primary edit-button' data-id='${customer.customer_id}'>View Motorcycle</button>
                             </td>
                        </tr>`
                    );
                });
            },
            error: function(xhr, status, error) {
                console.error("Error loading records:", error);
            }
        });
    }

    // Sorting functionality
    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        
        switch (sortOption) {
            case 'familyName':
                sortColumn = 'family_name';
                break;
            case 'firstName':
                sortColumn = 'first_name';
                break;
            case 'dateReg':
                sortColumn = 'date_reg';
                break;
            // Add more cases as needed
        }

        sortOrder = (sortOrder === 'ASC') ? 'DESC' : 'ASC';
        loadRecords($('#searchInput').val(), currentPage); // Reload records with sorting
    });

    loadRecords(); // Initial call

    // Edit record functionality
    $('#CustomerTableBody').on('click', '.edit-button', function() {
        const customerId = $(this).data('id');

        $.ajax({
            url: 'api/get_customer.php',
            method: 'GET',
            dataType: 'json',
            data: { customerId: customerId },
            success: function(response) {
                if (response && response.customer) {
                    const customer = response.customer;
                    $('#editCustomerId').val(customer.customer_id);
                    $('#editFamilyName').val(customer.family_name);
                    $('#editFirstName').val(customer.first_name);
                    $('#editMiddleName').val(customer.middle_initial);

                    // Fetch motorcycle details
                    $.ajax({
                        url: 'api/get_motorcycle.php',
                        method: 'GET',
                        data: { customerId: customerId },
                        dataType: 'json',
                        success: function(motorcycleResponse) {
                            if (motorcycleResponse) {
                                $('#engineNo').val(motorcycleResponse.engine_no || '');
                                $('#chassisNo').val(motorcycleResponse.chassis_no || '');
                                $('#make').val(motorcycleResponse.make || '');
                                $('#yearModel').val(motorcycleResponse.year_model || '');
                                $('#series').val(motorcycleResponse.series || '');
                                $('#bodyType').val(motorcycleResponse.body_type || '');
                                $('#denomination').val(motorcycleResponse.denomination || '');
                                $('#datePurchase').val(motorcycleResponse.date_purchase || '');
                            } else {
                                alert('No motorcycle details found for this customer.');
                            }
                        },
                        error: function() {
                            alert('Error fetching motorcycle details');
                        }
                    });

                    $('#editRecordModal').modal('show');
                } else {
                    console.error('Invalid customer data:', response);
                }
            },
            error: function() {
                alert('Error fetching the record');
            }
        });
    });


    // Submit edited record
    $('#editRecordForm').on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: 'api/edit_customer.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords();
                    $('#editRecordModal').modal('hide');
                    showSuccessModal(response.message);
                } else {
                    $('#duplicateErrorMessage').text(response.message);
                    $('#duplicateErrorModal').modal('show');
                }
            },
            error: function(xhr, status, error) {
                console.error("Error saving record:", error);
            }
        });
    });

    function setupPagination(totalRecords) {
        const totalPages = Math.ceil(totalRecords / recordsPerPage);
        $('#prevPage').toggleClass('disabled', currentPage === 1);
        $('#nextPage').toggleClass('disabled', currentPage === totalPages);
    
        // Update the page link's state
        $('#prevPage a').attr('aria-disabled', currentPage === 1);
        $('#nextPage a').attr('aria-disabled', currentPage === totalPages);
    }
    
    $('#prevPage').on('click', function(e) {
        e.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            loadRecords($('#searchInput').val());
        }
    });
    
    $('#nextPage').on('click', function(e) {
        e.preventDefault();
        currentPage++;
        loadRecords($('#searchInput').val());
    });
    

    $('#searchInput').on('input', function() {
        loadRecords($(this).val());
    });
    

    
   
// Notification functionality
function fetchAndUpdateDropdownNotifications() {
    $.ajax({
        url: 'api/fetch_notifications.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var notificationsList = $('#notificationsList');
            var notificationCount = $('#notificationCount');
            
            notificationsList.empty(); // Clear the previous notifications
            if (data.length > 0) {
                data.forEach(function(notification) {
                    notificationsList.append(
                        `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                        `${notification.customer_name}: ${notification.message}` +
                        '</a></li>'
                    );
                });
                notificationCount.text(data.length);
            } else {
                notificationsList.append('<li><a class="notificationDropdown-item" href="staff_notifications.php">See All Notifications</a></li>');
                notificationCount.text('0');
            }
        },
        error: function() {
            $('#notificationsList').empty().append('<li><a class="dropdown-item" href="#">Failed to load notifications</a></li>');
            $('#notificationCount').text('0');
        }
    });
}

// Initial fetch and set up polling for dropdown notifications
fetchAndUpdateDropdownNotifications();
setInterval(fetchAndUpdateDropdownNotifications, 5000); // Poll every 5 seconds

$(document).on('click', '.notificationDropdown-item', function(e) { // Changed selector here
    e.preventDefault();
    var notificationId = $(this).data('id');

    // AJAX request to mark notification as read
    $.ajax({
        url: 'api/mark_notification_read.php', // Endpoint to mark as read
        type: 'POST',
        data: { id: notificationId },
        success: function() {
            // Update the UI after marking as read
            var notificationCount = $('#notificationCount');
            var currentCount = parseInt(notificationCount.text());
            
            // Decrease the notification count
            if (currentCount > 0) {
                notificationCount.text(currentCount - 1);
            }
            // Optionally remove or update the notification in the list
            $(`a[data-id="${notificationId}"]`).parent().remove();
        },
        error: function() {
            console.error('Failed to mark notification as read');
        }
    });

    // Redirect to staff_notifications.php with the notification ID in the URL
    window.location.href = 'staff_notifications.php?id=' + notificationId;
});

    // Sidebar toggle function
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }
    $('#sidebarToggle').on('click', toggleSidebar);
});
