$(document).ready(function() {
    let selectedRecordIds = [];
    let currentPage = 1;
    const recordsPerPage = 15;

    // Convert text inputs to uppercase
    function convertToUpperCase() {
        $(this).val($(this).val().toUpperCase());
    }
    $('#addRecordForm input[type="text"], #editRecordForm input[type="text"]').on('keyup input', convertToUpperCase);

    function loadRecords(query = '', page = 1) {
        $.ajax({
            url: 'api/fetch_customers.php',
            method: 'GET',
            data: { query: query, page: page },
            success: function(data) {
                const response = JSON.parse(data);
                const customers = response.customers;
    
                // Clear previous records
                $('#CustomerTableBody').empty();
    
                // Populate new records
                customers.forEach(customer => {
                    $('#CustomerTableBody').append(
                        `<tr data-id="${customer.customer_id}">
                             <td class='no-print'><input type='checkbox' class='customerCheckbox' data-id='${customer.customer_id}'></td>
                        <td>${customer.family_name}</td>
                        <td>${customer.first_name}</td>
                        <td>${customer.middle_initial}</td>
                        <td>${customer.branch}</td>
                        <td class='no-print'>
                            <button class='btn btn-sm text-white btn-primary edit-button' data-id='${customer.customer_id}'>View Motorcycle</button>
                        </td>
                    </tr>`
                    );
                });
    
                setupPagination(response.totalPages);
            },
            error: function(xhr, status, error) {
                console.error("Error loading records:", error);
            }
        });
    }
    
    loadRecords();

    // Setup pagination
    function setupPagination(totalPages) {
        const paginationContainer = $('#pagination');
        paginationContainer.empty();
        for (let i = 1; i <= totalPages; i++) {
            paginationContainer.append(`<a href="#" class="page-link" data-page="${i}">${i}</a>`);
        }
    }

    // Pagination link click handler
    $('#pagination').on('click', '.page-link', function(e) {
        e.preventDefault();
        currentPage = $(this).data('page');
        loadRecords($('#searchInput').val(), currentPage);
    });

    // Search functionality with debounce
    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }
    $('#searchInput').on('input', debounce(function() {
        loadRecords($(this).val(), 1); // Reset to first page on search
    }, 300));



$('#selectAll').on('change', function() {
    const isChecked = $(this).is(':checked');
    console.log("Select All checked:", isChecked); // Debugging
    $('#CustomerTableBody input.customerCheckbox').prop('checked', isChecked);
    updateSelectedRecords();
});

function updateSelectedRecords() {
    selectedRecordIds = [];
    $('#CustomerTableBody input.customerCheckbox:checked').each(function() {
        selectedRecordIds.push($(this).data('id')); // Ensure this matches your data attribute
    });
    console.log("Selected IDs:", selectedRecordIds); // Debugging
}


    // Delete records
    $('#deleteSelectedButton').on('click', function() {
        if (selectedRecordIds.length > 0) {
            $('#confirmationModal').modal('show');
        } else {
            showWarningModal('No records selected for deletion.');
        }
    });

    $('#confirmDeleteBtn').on('click', function() {
        if (selectedRecordIds.length > 0) {
            $.ajax({
                url: 'api/delete_record.php',
                method: 'POST',
                data: { ids: selectedRecordIds },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        loadRecords($('#searchInput').val(), currentPage);
                        showSuccessModal(response.message);
                    } else {
                        showErrorModal(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error deleting records:", error);
                },
                complete: function() {
                    $('#confirmationModal').modal('hide');
                    selectedRecordIds = [];
                }
            });
        }
    });

    // Print records
    $('#printButton').on('click', function() {
        if (selectedRecordIds.length > 0) {
            printSelectedRecords();
        } else {
            showWarningModal('No records selected for printing.');
        }
    });
    

    function printSelectedRecords() {
        const printContent = $('<div></div>');
        const header = $('<div style="text-align: center; margin-bottom: 20px;">' +
            '<img src="img/smdi_logo.png" alt="SMDI_Logo" class="logo-tmdc mb-2" style="max-width: 150px;"/>' +
            '<h4 style="font-size: 16px; margin-bottom: 0;">Solid Motorcycle Distributors, Inc.</h4>' +
            '<p style="font-size: 12px; margin-bottom: 0;">1031 Victoria Bldg., Roxas Avenue, Roxas City, Capiz Philippines 5800</p>' +
            '<h2>Customer Lists</h2>' +
        '</div>');
        const table = $('<table class="table table-striped"></table>');
        const thead = $('<thead><tr><th>Family Name</th><th>First Name</th><th>Middle Initial</th><th>Branch</th></tr></thead>');
        const tbody = $('<tbody></tbody>');
    
        // Ensure this selector matches the checkboxes
        const selectedRows = $('#CustomerTableBody input.customerCheckbox:checked').closest('tr');
    
        if (selectedRows.length > 0) {
            printContent.append(header);
            table.append(thead);
    
            selectedRows.each(function() {
                const recordCells = $(this).find('td:not(.no-print)').map(function() {
                    return `<td>${$(this).text()}</td>`;
                }).get().join('');
    
                tbody.append(`<tr>${recordCells}</tr>`);
            });
    
            table.append(tbody);
            printContent.append(table);
    
            // Check the content before printing
            console.log(printContent.html()); // Debugging line
    
            printJS({
                printable: printContent.html(),
                type: 'raw-html',
                style: `/* styles as in your current code */`
            });
        } else {
            showWarningModal('No records selected for printing.');
        }
    }
    

    // Sorting functionality
    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        let columnIndex;

        switch (sortOption) {
            case 'familyName':
                columnIndex = 1; // Adjust to correct index
                break;
            case 'branch':
                columnIndex = 4; // Adjust to correct index (example index)
                break;
            default:
                return;
        }

        sortTable(columnIndex);
    });

    function sortTable(columnIndex) {
        const table = $('#CustomerTable');
        const rows = table.find('tbody tr').get();

        rows.sort(function(a, b) {
            const keyA = $(a).children('td').eq(columnIndex).text().toUpperCase();
            const keyB = $(b).children('td').eq(columnIndex).text().toUpperCase();

            return keyA.localeCompare(keyB);
        });

        $.each(rows, function(index, row) {
            table.children('tbody').append(row);
        });
    }

    // Notifications
    function fetchAndUpdateDropdownNotifications() {
        $.ajax({
            url: 'api/fetch_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                const notificationsList = $('#notificationsList');
                const notificationCount = $('#notificationCount');

                notificationsList.empty();
                if (data.length > 0) {
                    data.forEach(function(notification) {
                        notificationsList.append(
                            `<li><a class="notificationDropdown-item" href="#" data-id="${notification.id}">` +
                            `${notification.customer_name}: ${notification.message}` +
                            '</a></li>'
                        );
                    });
                    notificationCount.text(data.length);
                } else {
                    notificationsList.append('<li><a class="notificationDropdown-item" href="#">No notifications</a></li>');
                    notificationCount.text('0');
                }
            },
            error: function() {
                $('#notificationsList').empty().append('<li><a class="notificationDropdown-item" href="#">Failed to load notifications</a></li>');
                $('#notificationCount').text('0');
            }
        });
    }

    fetchAndUpdateDropdownNotifications();
    setInterval(fetchAndUpdateDropdownNotifications, 5000);

    $(document).on('click', '.notificationDropdown-item', function(e) {
        e.preventDefault();
        const notificationId = $(this).data('id');

        $.ajax({
            url: 'api/mark_notification_read.php',
            type: 'POST',
            data: { id: notificationId },
            success: function() {
                const notificationCount = $('#notificationCount');
                const currentCount = parseInt(notificationCount.text());

                if (currentCount > 0) {
                    notificationCount.text(currentCount - 1);
                }
                $(`a[data-id="${notificationId}"]`).parent().remove();
            },
            error: function() {
                console.error('Failed to mark notification as read');
            }
        });

        window.location.href = 'staff_notifications.php?id=' + notificationId;
    });

    // Edit record functionality
    $('#CustomerTableBody').on('click', '.edit-button', function() {
        const customerId = $(this).closest('tr').data('id');

        $.ajax({
            url: 'api/get_customer.php',
            method: 'GET',
            dataType: 'json',
            data: { customerId: customerId },
            success: function(response) {
                if (response && response.customer) {
                    const customer = response.customer;
                    $('#editCustomerId').val(customer.customer_id);
                    $('#editFamilyName').val(customer.family_name);
                    $('#editFirstName').val(customer.first_name);
                    $('#editMiddleName').val(customer.middle_initial);

                    $.ajax({
                        url: 'api/get_motorcycle.php',
                        method: 'GET',
                        data: { customerId: customerId },
                        dataType: 'json',
                        success: function(motorcycleResponse) {
                            $('#engineNo').val(motorcycleResponse.engine_no || '');
                            $('#chassisNo').val(motorcycleResponse.chassis_no || '');
                            $('#make').val(motorcycleResponse.make || '');
                            $('#yearModel').val(motorcycleResponse.year_model || '');
                            $('#series').val(motorcycleResponse.series || '');
                            $('#bodyType').val(motorcycleResponse.body_type || '');
                            $('#denomination').val(motorcycleResponse.denomination || '');
                            $('#datePurchase').val(motorcycleResponse.date_purchase || '');
                        },
                        error: function() {
                            alert('Error fetching motorcycle details');
                        }
                    });

                    $('#editRecordModal').modal('show');
                } else {
                    console.error('Invalid customer data:', response);
                }
            },
            error: function() {
                alert('Error fetching the record');
            }
        });
    });

    // Submit edited record
    $('#editRecordForm').on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: 'api/edit_customer.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadRecords($('#searchInput').val(), currentPage);
                    $('#editRecordModal').modal('hide');
                    showSuccessModal(response.message);
                } else {
                    $('#duplicateErrorMessage').text(response.message);
                    $('#duplicateErrorModal').modal('show');
                }
            },
            error: function(xhr, status, error) {
                console.error("Error saving record:", error);
            }
        });
    });

    // Modal functions
    function showSuccessModal(message) {
        $('#successMessage').text(message);
        $('#successModal').modal('show');
    }

    function showErrorModal(message) {
        $('#errorMessage').text(message);
        $('#errorMessage').show();
        setTimeout(() => $('#errorMessage').hide(), 3000);
    }

    function showWarningModal(message) {
        $('#warningMessage').text(message);
        $('#warningModal').modal('show');
    }

    // Sidebar toggle functionality
    function toggleSidebar() {
        $('.smdi-sidebar').toggleClass('smdi-sidebar--hidden');
        $('.smdi-main-content').toggleClass('smdi-main-content--full');
    }

    $('#sidebarToggle').on('click', toggleSidebar);
});
