<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRACK MO'TO </title>
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/styles.css">
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/generate_reports.js"></script>
</head>
<body>
 <!-- Sidebar -->
     <!-- Sidebar -->
     <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="dropdown-item" href="#">No notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
            <li class="nav-item">
                <a class="nav-link smdi-nav-link " href="staff_dashboard.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="staff_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="staff_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="smdi-main-content">
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
            <button id="sidebarToggle" class="btn btn-custom-toggle">
                &#9776;
            </button>
        </header>

        <div class="container mt-5">
            <h2>Generate Reports</h2>
            <form action="api/generate_reports.php" method="post" target="_blank">
                <div class="mb-3">
                    <label for="report_type" class="form-label">Select Report Type:</label>
                    <select id="report_type" name="report_type" class="form-select" required>
                        <option value="all">All</option>
                        <option value="LTO PLATE NUMBER">LTO PLATE NUMBER</option>
                        <option value="OR/CR">OR/CR</option>
                    </select>
                </div>

                <div class="mb-3" id="time_frame_container">
                    <label for="time_frame" class="form-label">Time Frame:</label>
                    <select id="time_frame" name="time_frame" class="form-select" required>
                        <option value="">Select Time Frame</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                        <option value="custom">Custom Date</option>
                    </select>
                </div>

                <div class="mb-3" id="custom_dates" style="display: none;">
                    <label for="start_date" class="form-label">Start Date:</label>
                    <input type="date" id="start_date" name="start_date" class="form-control">
                    <label for="end_date" class="form-label">End Date:</label>
                    <input type="date" id="end_date" name="end_date" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="document_status" class="form-label">Select Document Status:</label>
                    <select id="document_status" name="document_status" class="form-select" required>
                        <option value="all">All</option>
                        <option value="On Processing">On Processing</option>
                        <option value="Ready for Pick Up">Ready for Pick Up</option>
                        <option value="Released">Released</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="file_type" class="form-label">Select File Type:</label>
                    <select id="file_type" name="file_type" class="form-select" required>
                        <option value="pdf">PDF</option>
                        <option value="excel">Excel</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Generate Report</button>
            </form>
        </div>
    </div>

    <div class="smdi-overlay"></div>

</body>
</html>
