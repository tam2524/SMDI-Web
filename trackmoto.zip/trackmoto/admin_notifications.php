<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TRACK MO'TO</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/styles.css">
        <!-- Scripts -->
           <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
           <script src="js/staff_notifications.js"></script>

               <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>

    </head>
<body>
   <!-- Sidebar -->
    <nav class="smdi-sidebar d-flex flex-column">
        <div class="smdi-sidebar-logo text-center mb-3">
            <img src="img/tlogo.png" alt="smdi Logo" class="img-fluid">
        </div>
        
        <!-- Notification Area -->
        <div class="p-2">
            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                <!-- Notifications will be dynamically loaded here -->
                <li><a class="notificationDropdown-item" href="admin_notifications.php">See All notifications</a></li>
            </ul>
        </div>
        
        <ul class="nav flex-column p-2 smdi-sidebar-nav">
             <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="user_management.php">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_records.php">Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_customers.php">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link" href="admin_documents.php">Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link smdi-nav-link active" href="admin_generate_reports.php">Reports</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link smdi-nav-link smdi-logout-link" href="api/logout.php">Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="smdi-main-content">
        <!-- Toggle Button -->
        <header class="smdi-header d-flex justify-content-between align-items-center mb-4">
            <button id="sidebarToggle" class="btn btn-custom-toggle">
                &#9776; <!-- Unicode character for hamburger icon -->
            </button>
        </header>

        <div class="container mt-5 pt-5">
            <h1 class="my-4">Customer Follow-Up Notifications</h1>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer Name</th>
                            <th>Contact Number</th>
                            <th>Message</th>
                            <th>Document Name</th> <!-- Updated column header -->
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="notificationsTable">
                        <!-- Notifications will be populated here via JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    
    
        <!-- Success Modal -->
        <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="successModalLabel">Success</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <p id="successMessageText" class="mb-0">Message sent successfully.</p>
                    </div>
                </div>
            </div>
        </div>
    
        <!-- Error Modal -->
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">Error</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <p id="errorMessageText" class="mb-0">An error occurred.</p>
                    </div>
                </div>
            </div>
        </div>
    
        </main>

    <div class="smdi-overlay"></div>


</body>
</html>
