<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SMDI - LIAISON | The Highest Levels of Service</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Template Stylesheet -->
    <link href="css/styles.css" rel="stylesheet">
    
    <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
    <script src="js/staff_customers.js"></script>

    <style>
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <div class="container-fluid fixed-top">
        <div class="container topbar bg-primary d-none d-lg-block">
            <div class="d-flex justify-content-between">
                <div class="top-info ps-2">
                    <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-primary"></i> <a href="#" class="text-white">1031, Victoria Building, Roxas Avenue, Roxas City, 5800</a></small>
                </div>
                <div class="top-link pe-2"></div>
            </div>
        </div>
        <div class="container px-0">
            <nav class="navbar navbar-light bg-white navbar-expand-lg">
                <a href="staff_dashboard.php" class="navbar-brand">
                    <img src="img/smdi_logo.png" alt="Company Logo" class="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="staff_dashboard.php" class="nav-link">Records</a>
                        </li>
                        <li class="nav-item">
                            <a href="staff_customers.php" class="nav-link">Customers</a>
                        </li>
                        <li class="nav-item">
                            <a href="staff_documents.php" class="nav-link">Document Status</a>
                        </li>
                        <li class="nav-item">
                            <a href="api/logout.php" class="nav-link">Logout</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                                <!-- Notifications will be dynamically loaded here -->
                                <li><a class="dropdown-item" href="#">No notifications</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Main Container -->
    <div class="container-fluid py-5" style="margin-top: 120px;">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Customers</h5>
                <button id="printButton" class="btn btn-primary text-white mb-3">Print Customers</button>
                
                <!-- Search and Sort Options -->
                <div class="mb-3 d-flex">
                    <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
                    <div class="dropdown">
                        <button class="btn btn-primary text-white dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Sort by
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                            <li><a class="dropdown-item" href="#" data-sort="familyName">Family Name (A-Z)</a></li>
                            <li><a class="dropdown-item" href="#" data-sort="branch">Branch</a></li>
                        </ul>
                    </div>
                </div>

                <table id="CustomerTable" class="table table-striped">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAll"></th>
                            <th>Family Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Branch</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="CustomerTableBody">
                        <!-- Records will be dynamically loaded here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editRecordModal" tabindex="-1" aria-labelledby="editRecordModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editRecordModalLabel">Customer Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editRecordForm" action="edit_customer.php" method="post">
                        <input type="hidden" id="editCustomerId" name="customer_id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editFamilyName" class="form-label">Family Name</label>
                                <input type="text" class="form-control" id="editFamilyName" name="familyName" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editFirstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="editFirstName" name="firstName" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editMiddleName" class="form-label">Middle Name</label>
                                <input type="text" class="form-control" id="editMiddleName" name="middleName" readonly>
                            </div>
                        </div>
                        <div class="row">
                            <h5 class="modal-title" id="editRecordModalLabel">Motorcycle Details</h5>
                            <div class="col-md-6 mb-3">    
                                <label for="engineNo" class="form-label">Engine Number</label>
                                <input type="text" class="form-control" id="engineNo" name="engineNo" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="chassisNo" class="form-label">Chassis Number</label>
                                <input type="text" class="form-control" id="chassisNo" name="chassisNo" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="make" class="form-label">Make</label>
                                <input type="text" class="form-control" id="make" name="make" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="yearModel" class="form-label">Year Model</label>
                                <input type="text" class="form-control" id="yearModel" name="yearModel" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="series" class="form-label">Series</label>
                                <input type="text" class="form-control" id="series" name="series" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="bodyType" class="form-label">Body Type</label>
                                <input type="text" class="form-control" id="bodyType" name="bodyType" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="denomination" class="form-label">Denomination</label>
                                <input type="text" class="form-control" id="denomination" name="denomination" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="datePurchase" class="form-label">Date of Purchase</label>
                                <input type="date" class="form-control" id="datePurchase" name="datePurchase" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary text-white" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary text-white">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Success</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="successMessage">
                    <!-- Success message will be displayed here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Warning Modal -->
    <div class="modal fade" id="warningModal" tabindex="-1" aria-labelledby="warningModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="warningModalLabel">Warning</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="warningMessage">
                    <!-- Warning message will be displayed here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmationModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete the selected records?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="confirmDeleteBtn" class="btn btn-danger">Delete</button>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
