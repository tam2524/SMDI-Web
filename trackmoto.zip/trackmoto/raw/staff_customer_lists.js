$(document).ready(function () {
    let selectedCustomerIds = [];
    let customerIdToDelete = null;

    // Convert input text to uppercase on keyup/input
    $('#addRecordForm input[type="text"], #editRecordForm input[type="text"]').on('keyup input', function() {
        $(this).val($(this).val().toUpperCase());
    });

    function loadCustomers(query = '') {
        $.ajax({
            url: 'api/fetch_customers.php',
            method: 'GET',
            data: { query: query },
            success: function (data) {
                $('#CustomerTableBody').html(data);
            },
            error: function (xhr, status, error) {
                console.error('Error loading customers:', error);
            }
        });
    }

    // Initial load
    loadCustomers();

    // Search customers
    $('#searchInput').on('input', function() {
        const query = $(this).val();
        loadCustomers(query);
    });

    $('#RecordTableBody').on('change', 'input[name="recordCheckbox"]', function() {
        updateSelectedRecords();
    });

    $('#selectAll').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('#CustomerTableBody input[name="customerCheckbox"]').prop('checked', isChecked);
        updateSelectedCustomers();
    });

    $('#deleteSelectedButton').on('click', function() {
        if (selectedCustomerIds.length > 0) {
            $('#confirmationModal').modal('show');
        } else {
            showWarningModal('No records selected for deletion.');
        }
    });

    $('#confirmDeleteBtn').on('click', function() {
        if (selectedCustomerIds.length > 0) {
            $.ajax({
                url: 'api/delete_customer.php',
                method: 'POST',
                data: { ids: selectedCustomerIds },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        loadCustomers();
                        showSuccessModal(response.message);
                    } else {
                        showErrorModal(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error deleting customers:", error);
                },
                complete: function() {
                    $('#confirmationModal').modal('hide');
                    selectedCustomerIds = [];
                }
            });
        }
    });

    $('#printButton').on('click', function() {
        if (selectedCustomerIds.length > 0) {
            printSelectedCustomers();
        } else {
            showWarningModal('No records selected for printing.');
        }
    });

    function updateSelectedCustomers() {
        selectedCustomerIds = [];
        $('#CustomerTableBody input[name="customerCheckbox"]:checked').each(function() {
            selectedCustomerIds.push($(this).closest('tr').data('id'));
        });
    }

    function printSelectedCustomers() {
        const printContent = $('<div></div>');
        const header = $('<div style="text-align: center; margin-bottom: 20px;">' +
            '<img src="img/smdi_logo.png" alt="SMDI_Logo" class="logo-tmdc mb-2" style="max-width: 150px;"/>' +
            '<h4 style="font-size: 16px; margin-bottom: 0;">Solid Motorcycle Distributors, Inc.</h4>' +
            '<p style="font-size: 12px; margin-bottom: 0;">1031 Victoria Bldg., Roxas Avenue, Roxas City, Capiz Philippines 5800</p>' +
            '<h2>Customer Lists</h2>' +
        '</div>');
        const table = $('<table class="table table-striped"></table>');
        const thead = $('<thead><tr><th>Family Name</th><th>First Name</th><th>Middle Initial</th></tr></thead>');
        const tbody = $('<tbody></tbody>');

        const selectedRows = $('#CustomerTableBody input[name="customerCheckbox"]:checked').closest('tr');

        if (selectedRows.length > 0) {
            printContent.append(header);
            table.append(thead);

            selectedRows.each(function() {
                const customerCells = $(this).find('td:not(.no-print)').map(function() {
                    return `<td>${$(this).text()}</td>`;
                }).get().join('');

                tbody.append(`<tr>${customerCells}</tr>`);
            });

            table.append(tbody);
            printContent.append(table);

            printJS({
                printable: printContent.html(),
                type: 'raw-html',
                style: `
                    h2 {
                        text-align: center;
                        margin-bottom: 20px;
                        font-size: 24px;
                        font-weight: bold;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin: 20px 0;
                    }
                    th, td {
                        border: 1px solid #ccc;
                        padding: 10px;
                        text-align: left;
                    }
                    th {
                        font-size: 10px;
                        background-color: #f5f5f5;
                        font-weight: bold;
                        color: #333;
                        text-align: center;
                    }
                    td {
                        font-size: 14px;
                        border-bottom: 1px solid #e0e0e0;
                    }
                    .modal-footer, .modal-header {
                        display: none;
                    }
                    @media print {
                        body {
                            margin: 0;
                            padding: 0;
                            font-family: Arial, sans-serif;
                        }
                        .no-print {
                            display: none !important;
                        }
                        .modal-body {
                            padding: 0;
                            margin: 0;
                        }
                        .modal-content {
                            border: none;
                            box-shadow: none;
                        }
                        table {
                            margin: 0;
                            border: 1px solid #ddd;
                        }
                    }
                    @page {
                        margin: 1cm;
                    }
                `
            });
        } else {
            showWarningModal('No records selected for printing.');
        }
    }

    function showSuccessModal(message) {
        $('#successMessage').text(message);
        $('#successModal').modal('show');
    }

    function showErrorModal(message) {
        $('#errorMessage').text(message);
        $('#errorMessage').show();
        setTimeout(() => {
            $('#errorMessage').hide();
        }, 3000);
    }

    function showWarningModal(message) {
        $('#warningMessage').text(message);
        $('#warningModal').modal('show');
    }

    $('.dropdown-item').on('click', function(e) {
        e.preventDefault();
        const sortOption = $(this).data('sort');
        let columnIndex;

        switch (sortOption) {
            case 'familyName':
                columnIndex = 1; 
                break;
            default:
                return;
        }

        sortTable(columnIndex);
    });

    function sortTable(columnIndex) {
        const table = $('#CustomerTable');
        const rows = table.find('tbody tr').get();

        rows.sort(function(a, b) {
            const keyA = $(a).children('td').eq(columnIndex).text().toUpperCase();
            const keyB = $(b).children('td').eq(columnIndex).text().toUpperCase();

            if (keyA < keyB) return -1;
            if (keyA > keyB) return 1;
            return 0;
        });

        $.each(rows, function(index, row) {
            table.children('tbody').append(row);
        });
    }
    $('#CustomerTableBody').on('click', '.viewMotorcycleBtn', function() {
        let customerId = $(this).closest('tr').data('id');

        $.ajax({
            url: 'api/fetch_motorcycle_details.php',
            method: 'GET',
            data: { id: recordId },
            success: function(response) {
                let record = JSON.parse(response);

                $('#editRecordId').val(record.record_id);
                $('#editFamilyName').val(record.family_name);
                $('#editFirstName').val(record.first_name);
                $('#editMiddleName').val(record.middle_name);
                $('#editPlateNumber').val(record.plate_number);
                $('#editMvFile').val(record.mv_file);
                $('#editBranch').val(record.branch);
                $('#editBatch').val(record.batch);
                $('#editRemarks').val(record.remarks);

                $('#editRecordModal').modal('show');
            },
            error: function() {
                alert('Error fetching the record');
            }
        });
    });

    
});
