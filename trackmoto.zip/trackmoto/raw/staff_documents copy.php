<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SMDI - LIAISON | The Highest Levels of Service</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Template Stylesheet -->
    <link href="css/styles.css" rel="stylesheet">
    
    <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
    <script src="js/staff_documents.js"></script>

    <style>
        .table-responsive {
            overflow-x: auto;
        }
        .modal-lg {
            max-width: 90%;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="container-fluid fixed-top">
        <div class="container topbar bg-primary d-none d-lg-block">
            <div class="d-flex justify-content-between">
                <div class="top-info ps-2">
                    <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-primary"></i> <a href="#" class="text-white">1031, Victoria Building, Roxas Avenue, Roxas City, 5800</a></small>
                </div>
                <div class="top-link pe-2"></div>
            </div>
        </div>
        <div class="container px-0">
        <nav class="navbar navbar-light bg-white navbar-expand-lg">
                <a href="staff_dashboard.php" class="navbar-brand">
                    <img src="img/smdi_logo.png" alt="Company Logo" class="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="staff_dashboard.php" class="nav-link">Records</a>
                        </li>
                        <li class="nav-item">
                            <a href="staff_customers.php" class="nav-link">Customers</a>
                        </li>
                        <li class="nav-item">
                            <a href="staff_documents.php" class="nav-link">Document Status</a>
                        </li>
                        <li class="nav-item">
                            <a href="api/logout.php" class="nav-link">Logout</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                                <!-- Notifications will be dynamically loaded here -->
                                <li><a class="dropdown-item" href="#">No notifications</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar -->
    <!-- Main Container -->
    <div class="container-fluid py-5" style="margin-top: 120px;">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Document Status</h5>
                
                <!-- Filters and Search -->
                <div class="mb-3 d-flex">
                    <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
                    <div class="dropdown">
                        <button class="btn btn-primary text-white dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Sort by
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                            <li><a class="dropdown-item" href="#" data-sort="familyName">Family Name (A-Z)</a></li>                           
                        </ul>
                    </div>
                </div>
                <!-- Action Buttons -->
                <button class="btn btn-primary text-white mb-3" data-bs-toggle="modal" data-bs-target="#reportModal">Generate Report</button>
                
                <!-- Table of Documents -->
                <div class="table-responsive">
                    <table id="DocumentTable" class="table table-striped">
                        <thead>
                            <tr>
                                 <th data-column="document_id">ID</th>
                                <th data-column="customer_name">Customer Name</th>
                                <th data-column="document_type">Document Type</th>
                                <th data-column="document_number">Document Number</th>
                                <th>Status</th>
                                <th data-column="date_reg">Date Registered</th>
                            </tr>
                        </thead>
                        <tbody id="DocumentTableBody">
                            <!-- Rows will be populated here by JavaScript -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateStatusModalLabel">Update Document Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="updateStatusForm">
                        <input type="hidden" id="documentId" name="documentId">
                        <div class="mb-3">
                            <label for="documentTypeSelect" class="form-label">Document Type</label>
                            <select id="documentTypeSelect" name="documentType" class="form-select" required>
                                <option value="orcr">OR/CR</option>
                                <option value="lto">LTO Plate Number</option>
                            </select>
                        </div>
                        <div class="mb-3" id="mvFileNumberDiv">
                            <label for="mvFileNumber" class="form-label">MV File Number</label>
                            <input type="text" class="form-control" id="mvFileNumber" name="mvFileNumber">
                        </div>
                        <div class="mb-3" id="plateNumberDiv">
                            <label for="plateNumber" class="form-label">Plate Number</label>
                            <input type="text" class="form-control" id="plateNumber" name="plateNumber">
                        </div>
                        <div class="mb-3">
                            <label for="statusSelect" class="form-label">Status</label>
                            <select id="statusSelect" name="status" class="form-select" required>
                                <option value="on_processing">On Processing</option>
                                <option value="ready_for_pick_up">Ready for Pick Up</option>
                                <option value="released">Released</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary text-white">Update Status</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<!-- Report Generation Modal -->
<div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reportModalLabel">Generate Report</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="reportForm" method="post" action="api/generate_report.php">
                    <div class="mb-3">
                        <label for="reportType" class="form-label">Report Type</label>
                        <select id="reportType" name="reportType" class="form-select" required>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="yearly">Yearly</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="reportDocumentType" class="form-label">Document Type</label>
                        <select id="reportDocumentType" name="reportDocumentType" class="form-select" required>
                            <option value="both">Both</option>
                            <option value="orcr">OR/CR</option>
                            <option value="lto">LTO Plate Number</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="startDate" class="form-label">Start Date</label>
                        <input type="date" id="startDate" name="startDate" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="endDate" class="form-label">End Date</label>
                        <input type="date" id="endDate" name="endDate" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="reportStatus" class="form-label">Status</label>
                        <select id="reportStatus" name="reportStatus" class="form-select">
                            <option value="">All</option>
                            <option value="on_processing">On Processing</option>
                            <option value="ready_for_pick_up">Ready for Pick Up</option>
                            <option value="released">Released</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary text-white">Generate Report</button>
                </form>
            </div>
        </div>
    </div>
</div>

    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p id="successMessageText" class="mb-0">Status updated successfully.</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-light text-center py-3 mt-auto">
        <p>Copyright © 2024 Colegio de la Purisima Concepcion | Powered by MBC Creations</p>
    </footer>

</body>
</html>
