<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <title>SMDI - LIAISON | The Highest Levels of Service</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">
    
        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    
        <!-- Bootstrap CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        
        <!-- Template Stylesheet -->
        <link href="css/styles.css" rel="stylesheet">
        
        <!-- PrintJS -->
        <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
        <script src="js/staff_dashboard.js"></script>

        <style>
            .table-responsive {
                overflow-x: auto;
            }
        </style>
    </head>
    <body>
      <!-- Navbar-->
      <div class="container-fluid fixed-top">
        <div class="container topbar bg-primary d-none d-lg-block">
            <div class="d-flex justify-content-between">
                <div class="top-info ps-2">
                    <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-primary"></i> <a href="#" class="text-white">1031, Victoria Building, Roxas Avenue, Roxas City, 5800</a></small>
                </div>
                <div class="top-link pe-2"></div>
            </div>
        </div>
        <div class="container px-0">
            <nav class="navbar navbar-light bg-white navbar-expand-lg">
                <a href="staff_dashboard.php" class="navbar-brand">
                    <img src="img/smdi_logo.png" alt="Company Logo" class="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav">
                        <a href="staff_dashboard.php" class="nav-item nav-link">Records</a>
                        <a href="staff_customers.php" class="nav-item nav-link">Customers</a>
                        <a href="staff_documents.php" class="nav-item nav-link">Document Status</a>
                        <a href="api/logout.php" class="nav-item nav-link">Logout</a>
                    </div>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                                    <!-- Notifications will be dynamically loaded here -->
                                    <li><a class="dropdown-item" href="#">No notifications</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>

               
            </nav>
        </div>
    </div>
    <!-- Navbar-->

        <!-- Main Container -->
        <div class="container-fluid py-5" style="margin-top: 120px;">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Records</h5>
                    <button class="btn btn-primary text-white mb-3" data-bs-toggle="modal" data-bs-target="#addRecordModal">Add New Record</button>
                    <button id="printButton" class="btn btn-primary text-white mb-3">Print Masterlists</button>
                    <button id="printLabelsButton" class="btn btn-primary text-white mb-3">Print Labels</button>
                    <button id="deleteSelectedButton" class="btn btn-primary text-white mb-3">Delete Selected</button>
                    
                    
    <!-- Search and Sort Options -->
    <div class="mb-3 d-flex">
        <input type="text" id="searchInput" class="form-control me-2" placeholder="Search...">
        <div class="dropdown">
            <button class="btn btn-primary text-white dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                Sort by
            </button>
            <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                <li><a class="dropdown-item" href="#" data-sort="familyName">Family Name (A-Z)</a></li>
                <li><a class="dropdown-item" href="#" data-sort="batch">Batch</a></li>
                <li><a class="dropdown-item" href="#" data-sort="branch">Branch</a></li>
            </ul>
        </div>
    </div>

    <!-- Table of Records -->
            <table id="RecordTable" class="table table-striped">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>Date Registered</th>
                        <th>Family Name</th>
                        <th>First Name</th>
                        <th>Middle Initial</th>
                        <th>Plate Number</th>
                        <th>MV File</th>
                        <th>Branch</th>
                        <th>Batch</th>
                        <th>Remarks</th>
                    
                        
                        <th class="no-print">Actions</th>
                    </tr>
                </thead>
                <tbody id="RecordTableBody">
                    <!-- Records will be loaded here by AJAX -->
                </tbody>
            </table>
        </div>
            </div>
        </div>


    <!-- Add Record Modal -->
    <div class="modal fade" id="addRecordModal" tabindex="-1" aria-labelledby="addRecordModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addRecordModalLabel">Add Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div id="errorMessage" class="alert alert-danger" style="display: none;"></div>
                    <div id="successMessage" class="alert alert-success" style="display: none;"></div>
                    <form id="addRecordForm" action="add_Record.php" method="post">
                        <div class="row">
                                        
                <small style="font-size: 10px; color: red;"> ND if OR/CRE - LTO PLATE NUMBER is not available</small>
                            <div class="col-md-6 mb-3">
                                <label for="datereg" class="form-label">DateReg</label>
                                <input type="text" class="form-control" id="datereg" name="date_reg" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="familyName" class="form-label">Family Name</label>
                                <input type="text" class="form-control" id="familyName" name="family_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="firstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="firstName" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="middleInitial" class="form-label">Middle Initial</label>
                                <input type="text" class="form-control" id="middleInitial" name="middle_initial" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="plateNumber" class="form-label">Plate Number</label>
                                <input type="text" class="form-control" id="plateNumber" name="plate_number" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="mvFile" class="form-label">MV File</label>
                                <input type="text" class="form-control" id="mvFile" name="mv_file" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="branch" class="form-label">Branch</label>
                                <input type="text" class="form-control" id="branch" name="branch" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="batch" class="form-label">Batch</label>
                                <input type="text" class="form-control" id="batch" name="batch" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="remarks" class="form-label">Remarks</label>
                                <input type="text" class="form-control" id="remarks" name="remarks" required>
                            </div>
                        </div>
                        <div class="text-end"> 
                            <button type="submit" class="btn btn-primary text-white">Add Record</button>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Modal -->
    <div class="modal fade" id="editRecordModal" tabindex="-1" aria-labelledby="editRecordModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editRecordModalLabel">Edit Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editRecordForm" action="edit_Record.php" method="post">
                        <input type="hidden" id="editRecordId" name="record_id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editDatereg" class="form-label">DateReg</label>
                                <input type="text" class="form-control" id="editDatereg" name="date_reg">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editFamilyName" class="form-label">Family Name</label>
                                <input type="text" class="form-control" id="editFamilyName" name="family_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editFirstName" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="editFirstName" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editMiddleInitial" class="form-label">Middle Initial</label>
                                <input type="text" class="form-control" id="editMiddleInitial" name="middle_initial" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editPlateNumber" class="form-label">Plate Number</label>
                                <input type="text" class="form-control" id="editPlateNumber" name="plate_number" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editMvFile" class="form-label">MV File</label>
                                <input type="text" class="form-control" id="editMvFile" name="mv_file" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="editBranch" class="form-label">Branch</label>
                                <input type="text" class="form-control" id="editBranch" name="branch" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="editBatch" class="form-label">Batch</label>
                                <input type="text" class="form-control" id="editBatch" name="batch" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editRemarks" class="form-label">Remarks</label>
                                <input type="text" class="form-control" id="editRemarks" name="remarks" required>
                            </div>
                           
                        </div>
                        <div class="text-end"> 
                        <button type="submit" class="btn text-white btn-primary ">Save Changes</button>
                        </div>
                </form> 
                </div>
            </div>
        </div>
    </div>
        <!-- Success Modal -->
        <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p id="successMessage">Successful!</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Confirmation Modal -->
        <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmationModalLabel">Confirm Deletion</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this record?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="confirmDeleteBtn" class="btn btn-primary text-white">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    <!-- Duplicate Error Modal -->
    <div class="modal fade" id="duplicateErrorModal" tabindex="-1" aria-labelledby="duplicateErrorModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="duplicateErrorModalLabel">Duplicate Record!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="duplicateErrorMessage">A record with this name already exists.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary text-white" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Warning Modal -->
    <div class="modal fade" id="warningModal" tabindex="-1" role="dialog" aria-labelledby="warningModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="warningModalLabel">Warning</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

        </div>
        <div class="modal-body">
            <p id="warningMessage"></p>
        </div>
        </div>
    </div>
    </div>
    <!-- Footer -->
    <footer class="bg-dark text-light text-center py-3 mt-auto">
        <p>Copyright © 2024 Colegio de la Purisima Concepcion | Powered by MBC Creations</p>
    </footer>

    </body>

    </html>