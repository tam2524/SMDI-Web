<?php
include 'db_config.php';

$query = $_GET['query'] ?? '';

$sql = "SELECT * FROM customers 
        WHERE family_name LIKE ? 
        OR first_name LIKE ? 
        OR middle_initial LIKE ?";

$stmt = mysqli_prepare($conn, $sql);
$searchTerm = "%$query%";
mysqli_stmt_bind_param($stmt, "sss", $searchTerm, $searchTerm, $searchTerm);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    while ($customer = mysqli_fetch_assoc($result)) {
        echo "<tr data-id='{$customer['id']}'>
                <td class='no-print'><input type='checkbox' name='customerCheckbox' data-id='{$customer['id']}'></td>
                <td>{$customer['id']}</td>
                <td>{$customer['family_name']}</td>
                <td>{$customer['first_name']}</td>
                <td>{$customer['middle_initial']}</td>
                <td class='no-print'>
                    <button class='btn btn-primary btn-sm viewMotorcycleBtn text-white' data-id='{$customer['id']}'>View Motorcycle</button>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No records found</td></tr>";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
