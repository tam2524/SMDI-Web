<?php include 'api/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SMDI - Staff Notifications</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Template Stylesheet -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- PrintJS -->
    <link rel="stylesheet" href="https://printjs-4de6.kxcdn.com/print.min.css">

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
    
    <!-- Your Custom JS -->
    <script src="js/staff_notifications.js"></script>

    <style>
        .table-responsive {
            overflow-x: auto;
        }
        .modal-lg {
            max-width: 90%;
        }
        .unread {
            font-weight: bold;
        }
        .email-item {
            cursor: pointer;
        }
    </style>
</head>

<body>
      <!-- Navbar-->
      <div class="container-fluid fixed-top">
        <div class="container topbar bg-primary d-none d-lg-block">
            <div class="d-flex justify-content-between">
                <div class="top-info ps-2">
                    <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-primary"></i> <a href="#" class="text-white">1031, Victoria Building, Roxas Avenue, Roxas City, 5800</a></small>
                </div>
                <div class="top-link pe-2"></div>
            </div>
        </div>
        <div class="container px-0">
            <nav class="navbar navbar-light bg-white navbar-expand-lg">
                <a href="staff_dashboard.php" class="navbar-brand">
                    <img src="img/smdi_logo.png" alt="Company Logo" class="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav">
                        <a href="staff_dashboard.php" class="nav-item nav-link">Records</a>
                        <a href="staff_customers.php" class="nav-item nav-link">Customers</a>
                        <a href="staff_documents.php" class="nav-item nav-link">Document Status</a>
                        <a href="api/logout.php" class="nav-item nav-link">Logout</a>
                    </div>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-bell"></i> <span id="notificationCount" class="badge bg-danger">0</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown" id="notificationsList">
                                    <!-- Notifications will be dynamically loaded here -->
                                    <li><a class="dropdown-item" href="#">No notifications</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>

               
            </nav>
        </div>
    </div>
    <!-- Navbar-->

    <!-- Main Content -->
    <div class="container mt-5 pt-5">
        <h1 class="my-4">Customer Follow-Up Notifications</h1>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Contact Number</th>
                        <th>Message</th>
                        <th>Document Name</th> <!-- Updated column header -->
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="notificationsTable">
                    <!-- Notifications will be populated here via JavaScript -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- Follow-Up Modal -->
    <div class="modal fade" id="followUpModal" tabindex="-1" aria-labelledby="followUpModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="followUpModalLabel">Respond to Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="followUpForm">
                        <input type="hidden" id="notificationId" name="notificationId">
                        <input type="hidden" id="documentId" name="documentId">
                        <input type="hidden" id="customerName" name="customerName">
                        <div class="mb-3">
                            <label for="contactNumber" class="form-label">Contact Number</label>
                            <input type="text" class="form-control" id="contactNumber" name="contactNumber" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="documentName" class="form-label">Document Name</label>
                            <input type="text" class="form-control" id="documentName" name="documentName" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="documentStatus" class="form-label">Document Status</label>
                            <input type="text" class="form-control" id="documentStatus" name="documentStatus" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="responseMessage" class="form-label">Response Message</label>
                            <textarea class="form-control" id="responseMessage" name="responseMessage" rows="4" required></textarea>
                        </div>
                        <div class="text-end"> 
                            <button type="submit" class="btn btn-primary text-white">Send Response</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Success</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p id="successMessageText" class="mb-0">Message sent successfully.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Error Modal -->
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="errorModalLabel">Error</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p id="errorMessageText" class="mb-0">An error occurred.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-light text-center py-3 mt-auto">
        <p>Copyright © 2024 Colegio de la Purisima Concepcion | Powered by MBC Creations</p>
    </footer>
   
</body>

</html>
